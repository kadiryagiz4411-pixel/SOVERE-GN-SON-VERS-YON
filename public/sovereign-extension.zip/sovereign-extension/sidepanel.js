const CANONICAL_API = 'https://sovereignapp.pro';
const PARSE_DOM_URL = `${CANONICAL_API}/api/extension/parse-dom`;
const STORE = {
  SETTINGS: 'sovereign.settings.v1',
  PROPOSALS: 'sovereign.proposals.v1',
  CANDIDATES: 'sovereign.candidates.v1',
  CVS: 'sovereign.tailored-cvs.v1',
  SESSION: 'sovereign.session.v1',
  GUEST: 'sovereign.guest.actions.v1',
  LEADS: 'sovereign.leads.v1',
  ACTIONS: 'sovereign.actions.v1',
  RATED: 'sovereign.rated.v1',
  VIEWPORT: 'sovereign.viewport.v1',
  DEFAULT_CV: 'sovereign.default-cv.v1',
};
const DEFAULT_SETTINGS = {
  skills: '',
  hourlyRate: '',
  fixedRate: '',
  experience: 'mid',
  theme: 'obsidian',
  membership: 'unknown',
  accountEmail: '',
  role: '',
  workspaceMode: 'b2c',
  workspace: 'b2c',
  b2bAccess: false,
  isAdmin: false,
  isAppsumoUser: false,
  appsumoTier: 0,
  remainingCredits: 0,
  singlePassCredits: 0,
  planType: '',
  monthlyCreditLimit: 0,
  subscriptionStatus: 'unknown',
  canGenerate: true,
  // English is the absolute default. Auto-detect is opt-in from Settings.
  outputLanguage: 'en',
  languageChoice: 'explicit',
  referralCode: '',
  profession: '',
  pastWins: '',
  portfolio: '',
};

/** Page language drives analysis unless the user saved an explicit Settings choice.
 *  Never read navigator.language — a Turkish browser must not rewrite an English job.
 */
const UI_TITLE_NOISE = /^(giri[sş]\s*yap(?:mak|ın|iniz)?|oturum\s*aç(?:ın)?|sign\s*in|log\s*in|join\s*now|translate(?:\s+this\s+page)?|türkçe|english|menu|home)$/i;

/** Drop browser-chrome labels so a Turkish "Giriş yapmak" button never becomes a card title. */
function cleanCardTitle(value, fallback) {
  const text = String(value || '').replace(/\s+/g, ' ').trim();
  if (!text || UI_TITLE_NOISE.test(text)) return fallback || 'Untitled proposal';
  return text;
}

function rememberPageLanguage(code) {
  const lang = String(code || '').trim().toLowerCase().split('-')[0];
  if (lang === 'en' || (/^[a-z]{2}$/.test(lang) && lang !== 'tr')) {
    settings = { ...settings, _detectedLang: lang };
  }
}

function detectSourceLanguage(sample) {
  const text = String(sample || '').replace(/\s+/g, ' ').slice(0, 4000);
  if (text.length < 40) return 'en';
  const score = (marks, words, minMarks) => {
    const markHits = (text.match(marks) || []).length;
    if (minMarks && markHits < minMarks) return 0;
    return markHits * 3 + (text.match(words) || []).length;
  };
  const ranked = [
    ['en', score(/$/g, /\b(the|and|with|for|you|your|this|that|from|have|will)\b/gi, 0)],
    ['tr', score(/[ğüşıöçĞÜŞİÖÇ]/g, /\b(ve|bir|için|ile|olan|değil|bu|çok|daha|veya)\b/gi, 3)],
    ['de', score(/[äöüßÄÖÜ]/g, /\b(und|der|die|das|mit|für|nicht|eine|ist)\b/gi, 2)],
    ['fr', score(/[éèêëàùçœÉÈÊËÀÙÇ]/g, /\b(les|des|une|pour|dans|avec|vous|est|pas)\b/gi, 2)],
    ['es', score(/[ñ¿¡áéíóúÁÉÍÓÚ]/g, /\b(los|las|para|con|una|que|del|por|como)\b/gi, 2)],
  ].sort((a, b) => b[1] - a[1]);
  if (ranked[0][1] < 3) return 'en';
  if (ranked[0][0] !== 'en' && ranked[0][1] < ranked[1][1] + 3) return 'en';
  return ranked[0][0];
}

function resolveOutputLanguage(sourceText) {
  const saved = String(settings.outputLanguage || 'en').trim().toLowerCase();
  const explicit = settings.languageChoice === 'explicit' && saved && saved !== 'auto';
  if (explicit && /^[a-z]{2}$/.test(saved)) return saved;
  if (settings.languageChoice === 'auto') {
    const fromSource = detectSourceLanguage(sourceText);
    if (/^[a-z]{2}$/.test(fromSource)) return fromSource;
  }
  return 'en';
}

function languagePayload(sourceText) {
  const code = resolveOutputLanguage(sourceText);
  return {
    outputLanguage: /^[a-z]{2}$/.test(code) ? code : 'en',
    target_language: /^[a-z]{2}$/.test(code) ? code : 'en',
  };
}

/** Race a promise against a timeout (ms). Resolves/rejects with whichever fires first. */
function withTimeout(promise, ms, message) {
  let t;
  const race = new Promise((resolve, reject) => {
    t = setTimeout(() => reject(new Error(message || 'timeout')), ms);
    Promise.resolve(promise).then(resolve, reject);
  });
  return race.finally(() => clearTimeout(t));
}

function liveAccountEmail() {
  const typed = document.getElementById('accountEmail')?.value;
  return String(typed || settings.accountEmail || '').trim().toLowerCase();
}

function isExtensionAdmin() {
  const email = liveAccountEmail();
  const allow = typeof ADMIN_EMAILS !== 'undefined' ? ADMIN_EMAILS : ['kadiryagiz4411@gmail.com'];
  const role = String(settings.role || '').toLowerCase();
  return settings.isAdmin === true
    || role === 'admin'
    || role === 'superadmin'
    || allow.includes(email);
}

function planBlob() {
  return `${settings.planType || ''} ${settings.membership || ''} ${settings.subscriptionTier || ''} ${settings.workspace || ''} ${settings.role || ''}`.toLowerCase();
}

function isUnlimitedAccount() {
  if (isExtensionAdmin()) return true;
  const blob = planBlob();
  return blob.includes('unlimited')
    || blob.includes('byok')
    || settings.canGenerate === true && Number(settings.monthlyCreditLimit || 0) <= 0 && Number(settings.remainingCredits || 0) >= 9999;
}

function isPaidSaaSWorkspace() {
  if (subscriptionLapsed()) return false;
  if (appsumoTier() === 1 || appsumoTier() === 2) return false;
  const blob = planBlob();
  const status = String(settings.subscriptionStatus || '').toLowerCase();
  const live = ['active', 'trialing', 'paid', 'lifetime', 'unknown', ''].includes(status);
  return live && /standard|starter|pro|elite|unlimited|enterprise|agency/.test(blob);
}

function isHighestTier() {
  if (isExtensionAdmin() || isUnlimitedAccount()) return true;
  if (appsumoTier() >= 3) return true;
  if (isPaidSaaSWorkspace()) return true;
  if (settings.b2bAccess === true || settings.b2bAccessState === 'granted') return true;
  const blob = planBlob();
  return blob.includes('enterprise')
    || blob.includes('agency')
    || blob.includes('b2b')
    || settings.workspace === 'dual';
}

function appsumoTier() {
  return Number(settings.appsumoTier || 0);
}

function subscriptionLapsed() {
  if (settings.isAppsumoUser || appsumoTier() >= 1) return false;
  const status = String(settings.subscriptionStatus || '').toLowerCase();
  return ['canceled', 'cancelled', 'expired', 'past_due', 'unpaid', 'paused'].includes(status);
}

function canUseB2B() {
  if (isHighestTier()) return true;
  if (appsumoTier() === 1 || appsumoTier() === 2) return false;
  if (subscriptionLapsed()) return false;
  return settings.b2bAccess === true || isPaidSaaSWorkspace();
}

function canUseDualWorkspace() {
  if (isHighestTier()) return true;
  return canUseB2B() && appsumoTier() !== 1 && appsumoTier() !== 2;
}

function isTopActiveTier() {
  if (isHighestTier()) return true;
  if (subscriptionLapsed()) return false;
  return settings.b2bAccess === true;
}

function canUseDeepMatch() {
  if (isExtensionAdmin()) return true;
  if (appsumoTier() >= 2) return true;
  if (appsumoTier() === 1) return false;
  const status = String(settings.subscriptionStatus || '').toLowerCase();
  if (['active', 'trialing', 'paid'].includes(status)) return true;
  const membership = String(settings.membership || '').toLowerCase();
  if (membership === 'pro' || membership === 'elite') return true;
  return settings.b2bAccess === true || settings.workspace === 'dual' || settings.workspace === 'b2b';
}

const APPSUMO_ZERO_MESSAGE = 'Monthly credits reached. Credits refresh next month, or upgrade for more.';

function hidePaywall() {
  document.getElementById('paywall')?.classList.remove('on');
}

function showCreditResetBanner() {
  document.getElementById('creditResetBanner')?.classList.add('on');
}

function hideCreditResetBanner() {
  document.getElementById('creditResetBanner')?.classList.remove('on');
}

function showPaywall(kind) {
  const title = document.getElementById('paywallTitle');
  const body = document.getElementById('paywallBody');
  const cta = document.getElementById('paywallCta');
  if (kind === 'appsumo') {
    if (title) title.textContent = 'Monthly credits reached';
    if (body) body.textContent = APPSUMO_ZERO_MESSAGE;
    if (cta) {
      cta.textContent = 'Upgrade plan';
      cta.href = 'https://sovereignapp.pro/pricing#appsumo';
    }
  } else if (kind === 'renew') {
    if (title) title.textContent = 'Renew your subscription';
    if (body) body.textContent = 'Your plan has expired or payment did not go through. Renew to restore CV, proposal, and extension access.';
    if (cta) {
      cta.textContent = 'Renew Subscription';
      cta.href = 'https://sovereignapp.pro/pricing';
    }
  } else {
    if (title) title.textContent = 'Upgrade your account';
    if (body) body.textContent = 'Your monthly credits are used up. Upgrade to keep generating CVs, proposals, and scrapes.';
    if (cta) {
      cta.textContent = 'Upgrade Account';
      cta.href = 'https://sovereignapp.pro/pricing';
    }
  }
  if (cta) {
    const hideUpgrade = (kind !== 'renew' && kind !== 'appsumo' && isTopActiveTier())
      || (kind === 'appsumo' && appsumoTier() >= 3);
    cta.hidden = hideUpgrade;
  }
  document.getElementById('paywall')?.classList.add('on');
}

const RATE_COPY = {
  en: { title: 'How is Sovereign so far?', body: 'A short review helps other freelancers find it.', cta: 'Rate on the Chrome Web Store', later: 'Not now' },
  tr: { title: 'Sovereign şimdiye kadar nasıl?', body: 'Kısa bir değerlendirme, diğer freelancerların ürünü bulmasına yardım eder.', cta: 'Chrome Web Mağazasında puan ver', later: 'Şimdi değil' },
  de: { title: 'Wie gefällt dir Sovereign?', body: 'Eine kurze Bewertung hilft anderen Freelancern, es zu finden.', cta: 'Im Chrome Web Store bewerten', later: 'Nicht jetzt' },
  fr: { title: 'Sovereign vous convient-il?', body: 'Un court avis aide d’autres freelances à le trouver.', cta: 'Noter sur le Chrome Web Store', later: 'Pas maintenant' },
  es: { title: '¿Qué te parece Sovereign?', body: 'Una reseña breve ayuda a otros freelancers a encontrarlo.', cta: 'Valorar en Chrome Web Store', later: 'Ahora no' },
};

function reviewUrl() {
  try {
    const id = chrome.runtime?.id || '';
    if (/^[a-p]{32}$/.test(id)) return `https://chromewebstore.google.com/detail/${id}/reviews`;
  } catch { /* opened outside the extension */ }
  return 'https://sovereignapp.pro/reviews';
}

function uiLanguage() {
  const saved = String(settings.outputLanguage || 'auto').trim().toLowerCase();
  if (settings.languageChoice === 'explicit' && RATE_COPY[saved]) return saved;
  const detected = String(settings._detectedLang || '').split('-')[0];
  return RATE_COPY[detected] ? detected : 'en';
}

async function showRatePrompt() {
  try {
    if (await storageGet(STORE.RATED, false)) return;
    const copy = RATE_COPY[uiLanguage()] || RATE_COPY.en;
    const modal = document.getElementById('rateModal');
    const title = document.getElementById('rateTitle');
    const body = document.getElementById('rateBody');
    const store = document.getElementById('rateStore');
    const later = document.getElementById('rateLater');
    if (title) title.textContent = copy.title;
    if (body) body.textContent = copy.body;
    if (store) {
      store.textContent = copy.cta;
      store.href = reviewUrl();
    }
    if (later) later.textContent = copy.later;
    modal?.classList.add('on');
  } catch (err) {
    console.error('[sovereign] rate prompt', err);
  }
}

async function noteAiSuccess() {
  try {
    const count = Number(await storageGet(STORE.ACTIONS, 0)) + 1;
    await storageSet(STORE.ACTIONS, count);
    if (count > 0 && count % 10 === 0) await showRatePrompt();
  } catch (err) {
    console.error('[sovereign] action count', err);
  }
}

function referralUrl() {
  const code = String(settings.referralCode || '').trim().toLowerCase();
  if (!/^[a-z0-9_-]{4,32}$/.test(code)) return '';
  return `https://sovereignapp.pro/ref?code=${encodeURIComponent(code)}`;
}

function applyCreditBadge() {
  const el = document.getElementById('creditBadge');
  if (!el) return;
  if (isExtensionAdmin()) {
    el.classList.add('hidden');
    return;
  }
  if (!settings.accountEmail) {
    const remaining = Math.max(0, 2 - Number(settings._guestUsed || 0));
    el.classList.remove('hidden');
    el.classList.toggle('empty', remaining <= 0);
    el.classList.toggle('pro', remaining > 0);
    el.textContent = remaining === 1 ? '1 Pass' : `${remaining} Passes`;
    return;
  }
  el.classList.remove('hidden');
  const remaining = Number(settings.remainingCredits || 0);
  const pass = Number(settings.singlePassCredits || 0);
  const limit = Number(settings.monthlyCreditLimit || 0);
  const plan = String(settings.planType || '').toLowerCase();
  const status = String(settings.subscriptionStatus || '').toLowerCase();
  const subscribed = status === 'active' || status === 'lifetime' || status === 'on_trial';
  const elite = subscribed && /elite/.test(plan);
  const agency = subscribed && /enterprise|agency|b2b/.test(plan);
  const pro = subscribed && /pro/.test(plan);
  el.classList.toggle('empty', remaining <= 0 && pass <= 0 && !pro && !elite && !agency);
  el.classList.toggle('pro', Boolean(pro || elite || agency || pass > 0));
  if (settings.isAppsumoUser && remaining <= 0 && pass <= 0) showCreditResetBanner();
  else hideCreditResetBanner();
  if (elite) { el.textContent = 'Elite Active'; return; }
  if (agency) { el.textContent = 'Agency Active'; return; }
  if (pro) { el.textContent = 'Pro Active'; return; }
  if (pass > 0) {
    el.textContent = pass === 1 ? '1 Pass' : `${pass} Passes`;
    return;
  }
  if (settings.isAppsumoUser) {
    const tier = appsumoTier();
    const label = tier >= 3 ? 'T3' : tier === 2 ? 'T2' : tier === 1 ? 'T1' : '';
    el.textContent = remaining <= 0
      ? (label ? `${label} · resets next month` : 'Credits reset next month')
      : (limit > 0 ? `${label} ${remaining}/${limit}`.replace('  ', ' ') : `Credits ${remaining}`);
    return;
  }
  el.textContent = limit > 0 ? `Credits ${remaining}/${limit}` : `Credits ${remaining}`;
}

async function guestState() {
  const bag = await storageGet(STORE.GUEST, { used: 0, id: '', token: '' });
  const id = String(bag?.id || '').trim() || `g_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  const used = Math.max(0, Number(bag?.used || 0));
  const token = String(bag?.token || '').trim();
  if (!bag?.id) await storageSet(STORE.GUEST, { id, used, token, at: Date.now() });
  return { id, used, token };
}

async function recordGuestUse(token) {
  if (settings.accountEmail) return;
  const current = await guestState();
  const nextToken = String(token || current.token || '').trim();
  const tokenUsed = Number(String(nextToken.split('.')[1] || ''));
  const used = Math.min(2, Number.isFinite(tokenUsed) ? tokenUsed : current.used + 1);
  settings._guestUsed = used;
  await storageSet(STORE.GUEST, {
    id: nextToken.split('.')[0] || current.id,
    used,
    token: nextToken,
    at: Date.now(),
  });
  applyCreditBadge();
}

function showGuestGate() {
  document.getElementById('guestGate')?.classList.add('on');
}

function hideGuestGate() {
  document.getElementById('guestGate')?.classList.remove('on');
}

function assertGenerationAllowed() {
  if (isExtensionAdmin()) return true;
  if (!settings.accountEmail) {
    const used = Number((settings._guestUsed || 0));
    if (used >= 2) {
      showGuestGate();
      setBusy(false, 'Sign in to keep generating.');
      return false;
    }
    return true;
  }
  const remaining = Number(settings.remainingCredits || 0);
  const pass = Number(settings.singlePassCredits || 0);
  if (pass > 0) {
    hideCreditResetBanner();
    hidePaywall();
    return true;
  }
  if (settings.isAppsumoUser) {
    if (remaining <= 0) {
      hidePaywall();
      showCreditResetBanner();
      setBusy(false, APPSUMO_ZERO_MESSAGE);
      return false;
    }
    hideCreditResetBanner();
    return true;
  }
  const status = String(settings.subscriptionStatus || '').toLowerCase();
  if (['canceled', 'cancelled', 'expired', 'past_due', 'unpaid', 'paused'].includes(status) && remaining <= 0) {
    showPaywall('renew');
    setBusy(false, 'Renew your subscription to keep using Sovereign.');
    return false;
  }
  if (settings.canGenerate === false || remaining <= 0) {
    showPaywall('upgrade');
    setBusy(false, 'Get a $1.99 Single Pass or subscribe to keep generating.');
    return false;
  }
  return true;
}

function effectiveMode() {
  return settings.workspaceMode === 'b2b' ? 'b2b' : 'b2c';
}

function publicError(raw) {
  const text = String(raw || '');
  if (isExtensionAdmin()) return text || 'Unknown error';
  if (/Open a job post on LinkedIn/i.test(text)) {
    return 'Open a job post on LinkedIn, Upwork, or any webpage to scan.';
  }
  if (/too short|open a job|Open a job post/i.test(text)) {
    return 'Open a job post on LinkedIn, Upwork, or any webpage to scan.';
  }
  if (/readable text|enough readable/i.test(text)) {
    return 'Open a job post on LinkedIn, Upwork, or any webpage to scan.';
  }
  if (/permission|host permissions|Reload this unpacked/i.test(text)) {
    return 'Reload the extension, then scan again.';
  }
  if (/system pages|chrome system|chrome:\/\/|edge:\/\/|about:/i.test(text)) {
    return 'Open a job post on LinkedIn, Upwork, or any webpage to scan.';
  }
  if (/no proposal editor|no editor found|Auto-Fill is not loaded/i.test(text)) {
    return 'Open the cover letter or proposal box on this page, then tap Auto-Fill again.';
  }
  if (/failed to fetch|networkerror|load failed|cors|NetworkError|TypeError: Failed/i.test(text)) {
    return 'Could not reach Sovereign. Check your connection and try again.';
  }
  if (/401|sign in|unauthorized|jwt|session expired/i.test(text)) {
    return 'Session expired, please sign in';
  }
  if (/Server Error|ECONN|timeout|502|503|504|Retrying/i.test(text)) {
    return 'Connection timeout. Retrying.';
  }
  return text && text.length < 160 && !/https?:|at\s+\w+\s+\(/i.test(text)
    ? text
    : 'Could not finish this scan. Try again.';
}

const statusEl = document.getElementById('status');
const spinner = document.getElementById('spinner');
const card = document.getElementById('card');
const modeBadge = document.getElementById('modeBadge');
const badge = document.getElementById('badge');
const scoreRing = document.getElementById('scoreRing');
const scoreLabel = document.getElementById('scoreLabel');
const scoreHeading = document.getElementById('scoreHeading');
const titleEl = document.getElementById('title');
const metaEl = document.getElementById('meta');
const painEl = document.getElementById('pain');
const painHeading = document.getElementById('painHeading');
const bodyHeading = document.getElementById('bodyHeading');
const proposalEl = document.getElementById('proposal');
const analyzeBtn = document.getElementById('analyze');
const copyBtn = document.getElementById('copy');
const autofillBtn = document.getElementById('autofill');
const viewJobLink = document.getElementById('viewJob');
const actionsJobLink = document.getElementById('actionsJobLink');
const saveCandidateBtn = document.getElementById('saveCandidate');
const outreachBtn = document.getElementById('outreach');
const actionsJob = document.getElementById('actionsJob');
const actionsDeploy = document.getElementById('actionsDeploy');
const deployBtn = document.getElementById('deploy');
const actionsCv = document.getElementById('actionsCv');
const actionsB2b = document.getElementById('actionsB2b');
const errorBadge = document.getElementById('errorBadge');
const apiBadge = document.getElementById('apiBadge');
const apiStatusDetail = document.getElementById('apiStatusDetail');
const proposalListEl = document.getElementById('proposalList');
const cvListEl = document.getElementById('cvList');
const profileStatus = document.getElementById('profileStatus');
const planStatus = document.getElementById('planStatus');

let lastProposal = '';
let lastOutreach = '';
let lastCandidate = null;
let lastCv = '';
let lastJobUrl = '';
let lastTitle = '';
let lastScore = 0;
let lastMatch = {
  label: '',
  strengths: [],
  gaps: [],
  message: '',
  onboardingRequired: false,
  acceptanceScore: 0,
};
let lastJob = {
  title: '',
  url: '',
  description: '',
  skills: [],
  budget: '',
  clientHistory: '',
  kind: 'job',
  hash: '',
};
let lastTargetHash = '';
let viewportScoreTimer = 0;
let analyzing = false;
let scanSeq = 0;
let generatingCv = false;
let settings = { ...DEFAULT_SETTINGS };

function apiBase() {
  try {
    return canonicalizeApiBase(typeof API_BASE_URL !== 'undefined' ? API_BASE_URL : CANONICAL_API);
  } catch {
    return CANONICAL_API;
  }
}

function parsePath() {
  return typeof PARSE_DOM_PATH === 'string' ? PARSE_DOM_PATH : '/api/extension/parse-dom';
}

function parseDomUrl() {
  return `${apiBase()}${parsePath()}`;
}

function isRestrictedUrl(href) {
  return /^(chrome|edge|about|chrome-extension|moz-extension|devtools):/i.test(String(href || ''))
    || /chromewebstore\.google\.com|chrome\.google\.com\/webstore/i.test(String(href || ''));
}

function escapeHtml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

async function storageGet(key, fallback) {
  try {
    const bag = await withTimeout(chrome.storage.local.get(key), 2500, 'storage');
    if (bag?.[key] != null) return bag[key];
  } catch {}
  try {
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw);
  } catch {}
  return fallback;
}

async function storageSet(key, value) {
  let chromeOk = false;
  let chromeError = null;
  try {
    await chrome.storage.local.set({ [key]: value });
    chromeOk = true;
  } catch (err) {
    chromeError = err;
  }
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    if (!chromeOk) throw chromeError || err;
  }
}

function skillListFromSettings() {
  return String(settings.skills || '')
    .split(/[,|\n]+/)
    .map((item) => item.trim())
    .filter((item) => item.length >= 2)
    .slice(0, 24);
}

/**
 * Returns the user's skill list when they have at least two skills.
 * Otherwise scores against Freelance and General so match calculation still runs.
 */
function effectiveSkillList() {
  const skills = skillListFromSettings();
  if (skills.length >= 2) return skills;
  return ['Freelance', 'General'];
}

function hideErrorBadge() {
  if (!errorBadge) return;
  errorBadge.classList.add('hidden');
  errorBadge.textContent = '';
}

function showError(message) {
  spinner?.classList.remove('on');
  analyzing = false;
  if (analyzeBtn) analyzeBtn.disabled = false;
  if (copyBtn) copyBtn.disabled = false;
  if (autofillBtn) autofillBtn.disabled = false;
  if (saveCandidateBtn) saveCandidateBtn.disabled = false;
  if (outreachBtn) outreachBtn.disabled = false;
  const text = publicError(message);
  if (statusEl) {
    statusEl.classList.add('err');
    statusEl.textContent = text;
  }
  if (errorBadge) {
    errorBadge.classList.remove('hidden');
    const detail = isExtensionAdmin()
      ? `<br/><span style="opacity:.8">POST ${escapeHtml(parseDomUrl())}</span>`
      : '';
    errorBadge.innerHTML = `${escapeHtml(text)}${detail}`;
  }
}

function setBusy(on, message) {
  analyzing = on;
  if (analyzeBtn) analyzeBtn.disabled = on;
  if (copyBtn) copyBtn.disabled = on;
  if (autofillBtn) autofillBtn.disabled = on;
  if (saveCandidateBtn) saveCandidateBtn.disabled = on;
  if (outreachBtn) outreachBtn.disabled = on;
  spinner?.classList.toggle('on', on);
  if (statusEl) {
    statusEl.textContent = message;
    statusEl.classList.remove('err');
  }
  if (!on) hideErrorBadge();
}

function setActiveChannel(url) {
  const host = String(url || '').toLowerCase();
  const key = host.includes('indeed.') ? 'indeed'
    : host.includes('glassdoor.') ? 'glassdoor'
    : host.includes('linkedin.com') ? 'linkedin'
    : host.includes('upwork.com') ? 'upwork'
    : '';
  document.querySelectorAll('[data-channel]').forEach((el) => {
    const on = Boolean(key) && el.getAttribute('data-channel') === key;
    el.classList.toggle('on', on);
    const badge = el.querySelector('[data-live]');
    if (badge) badge.textContent = on ? 'Live' : 'Connect';
    el.setAttribute('aria-pressed', on ? 'true' : 'false');
  });
}

function sanitizeStructuredJob(job) {
  if (!job || typeof job !== 'object') return null;
  const clip = (value, max) => String(value || '').replace(/\s+/g, ' ').trim().slice(0, max);
  return {
    platform: clip(job.platform, 40),
    title: clip(job.title, 180),
    company: clip(job.company, 120),
    location: clip(job.location, 120),
    salary: clip(job.salary, 160),
    description: String(job.description || '').trim().slice(0, 12000),
    skills: Array.isArray(job.skills) ? job.skills.map((item) => String(item)).filter(Boolean).slice(0, 16) : [],
    budget: clip(job.budget, 160),
    clientInfo: clip(job.clientInfo, 500),
  };
}
function detectOpportunityPlatform(url) {
  const u = String(url || '').toLowerCase();
  if (u.includes('fiverr.com')) return 'Fiverr';
  if (u.includes('upwork.com')) return 'Upwork';
  if (u.includes('freelancer.com')) return 'Freelancer';
  if (u.includes('linkedin.com')) return 'LinkedIn';
  if (u.includes('indeed.')) return 'Indeed';
  if (u.includes('glassdoor.')) return 'Glassdoor';
  return 'Upwork';
}

async function ingestOpportunity(pageData, analysis) {
  const mode = analysis?.detectedMode || analysis?.type;
  if (mode !== 'JOB_PROPOSAL' && analysis?.intent !== 'JOB_POSTINGS') return;
  const platform = detectOpportunityPlatform(pageData.pageUrl);
  const sessionBag = await storageGet(STORE.SESSION, null);
  const accessToken = sessionBag?.accessToken || '';
  const headers = {
    'Content-Type': 'application/json',
    'x-extension-id': chrome.runtime.id || '',
  };
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  fetch(`${apiBase()}/api/opportunities?t=${Date.now()}`, {
    method: 'POST',
    cache: 'no-store',
    headers,
    body: JSON.stringify({
      pageText: pageData.pageText,
      pageTitle: analysis.title || pageData.pageTitle,
      pageUrl: pageData.pageUrl,
      platform,
      skills: skillListFromSettings(),
      profile: {
        skills: skillListFromSettings(),
        experience: settings.experience,
        hourlyRate: Number(settings.hourlyRate) || null,
      },
      items: [{
        platform,
        title: analysis.title || pageData.pageTitle,
        description: analysis.painPoint || analysis.summary || String(pageData.pageText || '').slice(0, 1200),
        url: pageData.pageUrl,
        budget: '',
        compatibilityScore: analysis.compatibilityScore || analysis.overallScore,
      }],
    }),
  }).catch(() => {});
}

function copyText(value) {
  const text = String(value || '').trim();
  if (!text) return Promise.resolve(false);
  return navigator.clipboard.writeText(text).then(() => true).catch(() => {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
    return true;
  });
}

function formatWhen(ts) {
  try {
    return new Date(ts).toLocaleString();
  } catch {
    return '';
  }
}

async function saveProposalRecord(record) {
  try {
    const list = await withTimeout(storageGet(STORE.PROPOSALS, []), 4000, 'Save took too long. Try again.');
    const next = [record, ...(Array.isArray(list) ? list : [])].slice(0, 40);
    await withTimeout(storageSet(STORE.PROPOSALS, next), 4000, 'Save took too long. Try again.');
    renderProposalList(next);
    void renderSettingsHistory();
    if (statusEl && !analyzing) statusEl.textContent = 'Proposal saved on this device.';
  } catch (err) {
    console.error('[sovereign] save proposal', err);
    if (statusEl) {
      statusEl.textContent = 'Could not save this proposal. Try again.';
      statusEl.classList.add('err');
    }
  }
}

async function saveCandidateRecord(record) {
  const list = await storageGet(STORE.CANDIDATES, []);
  const next = [record, ...(Array.isArray(list) ? list : [])].slice(0, 40);
  await storageSet(STORE.CANDIDATES, next);
}

function renderProposalList(list) {
  if (!proposalListEl) return;
  if (!list?.length) {
    proposalListEl.innerHTML = '<div class="empty">No proposals saved yet. Analyze a job post to generate one.</div>';
    return;
  }
  proposalListEl.innerHTML = list.map((item) => `
    <article class="list-item" data-id="${escapeHtml(item.id)}">
      <h3>${escapeHtml(cleanCardTitle(item.title, 'Untitled proposal'))}</h3>
      <div class="when">${escapeHtml(formatWhen(item.at))} · ${escapeHtml(item.score || 0)}% match</div>
      <p>${escapeHtml(item.text || '')}</p>
      <div class="row">
        <button class="ghost" type="button" data-copy="${escapeHtml(item.id)}">Copy</button>
        <button class="danger" type="button" data-delete="${escapeHtml(item.id)}">Remove</button>
      </div>
    </article>
  `).join('');
}

function renderCvList(list) {
  if (!cvListEl) return;
  if (!list?.length) {
    cvListEl.innerHTML = '<div class="empty">No tailored CVs yet. Generate one from the open job.</div>';
    return;
  }
  cvListEl.innerHTML = list.map((item) => `
    <article class="list-item" data-id="${escapeHtml(item.id)}">
      <h3>${escapeHtml(cleanCardTitle(item.title, 'Tailored CV'))}</h3>
      <div class="when">${escapeHtml(item.score || 0)}% match · ${escapeHtml(formatWhen(item.at))}</div>
      <p>${escapeHtml(item.text || item.summary || '')}</p>
      <div class="row">
        <button class="ghost" type="button" data-copy="${escapeHtml(item.id)}">Copy</button>
        <button class="danger" type="button" data-delete="${escapeHtml(item.id)}">Remove</button>
      </div>
    </article>
  `).join('');
}

function clampScore(value) {
  const score = Math.round(Number(value));
  if (!Number.isFinite(score) || score <= 0) return 0;
  return Math.min(99, score);
}

function inspectHiringTargetJs(title, text, url) {
  const blob = `${title || ''}\n${text || ''}\n${url || ''}`.toLowerCase();
  const platform = /upwork/.test(blob) ? 'Upwork' : /linkedin/.test(blob) ? 'LinkedIn' : /fiverr/.test(blob) ? 'Fiverr' : '';
  const hiring = /hiring|looking for|we need|seeking|apply now|proposals? (left|remaining)|posted .*ago|applicants?|easy apply|job post|actively interviewing|urgently/.test(blob);
  const company = String(title || '').split(/[-–|·•]/)[0].trim().slice(0, 64);
  const handle = (String(text || '').match(/@([a-z0-9._-]{3,32})/i) || [])[0] || '';
  const marketplace = Boolean(platform);
  const active = marketplace && hiring;
  return { active, company, platform, recruiter: handle };
}

function paintPoach(title, text, url) {
  const target = inspectHiringTargetJs(title, text, url);
  const banner = document.getElementById('poachBanner');
  const meta = document.getElementById('poachMeta');
  banner?.classList.toggle('on', Boolean(target.active));
  if (meta) meta.textContent = [target.company, target.platform, target.recruiter].filter(Boolean).join(' · ');
}

function paintMonster(score) {
  const safe = clampScore(score);
  const card = document.getElementById('monsterCard');
  const ring = document.getElementById('monsterRing');
  const badge = document.getElementById('monsterBadge');
  const label = document.getElementById('monsterLabel');
  card?.classList.add('on');
  ring?.style.setProperty('--p', String(safe));
  if (badge) badge.textContent = String(safe);
  if (label) label.textContent = `${safe}/100 fit score`;
  lastScore = safe;
}

function armorResumeJs(resume, job) {
  const original = String(resume || '').trim();
  const hay = `${job || ''}\n${original}`.toLowerCase();
  const catalog = ['react', 'typescript', 'javascript', 'python', 'supabase', 'node', 'figma', 'aws', 'sql', 'next.js'];
  const missing = catalog.filter((skill) => hay.includes(skill) && !original.toLowerCase().includes(skill)).slice(0, 8);
  const skills = [...new Set([...catalog.filter((skill) => original.toLowerCase().includes(skill)), ...missing])];
  const name = original.split('\n').map((line) => line.trim()).find(Boolean) || 'Candidate';
  const armored = [
    `# ${name}`,
    '',
    '## Professional Summary',
    `${name} ships the brief in week one with measurable proof.`,
    '',
    '## Core Skills',
    skills.map((skill) => `- ${skill}`).join('\n'),
    '',
    '## Experience',
    original.split('\n').filter((line) => line.trim() && line.trim() !== name).slice(0, 40).map((line) => `- ${line.trim()}`).join('\n'),
  ].join('\n');
  return { original: original || 'No resume text yet.', armored };
}

function paintArmor(resume, job) {
  const result = armorResumeJs(resume, job);
  const card = document.getElementById('armorCard');
  const original = document.getElementById('armorOriginal');
  const armed = document.getElementById('armorArmed');
  if (original) original.textContent = result.original;
  if (armed) armed.textContent = result.armored;
  card?.classList.add('on');
}

function matchBand(score) {
  if (score >= 80) return 'High Probability';
  if (score >= 60) return 'Strong Fit';
  if (score >= 40) return 'Partial Fit';
  return 'Low Fit';
}

function chipHtml(items, kind) {
  if (!items?.length) return `<span class="hint">None yet.</span>`;
  return items.map((item) => `<span class="chip ${kind}">${escapeHtml(item)}</span>`).join('');
}

function humanMatchCopy(analysis, title) {
  const raw = String(analysis?.matchNarrative || analysis?.matchMessage || '').trim();
  const skillBlock = /at least two skills|complete onboarding/i.test(raw);
  if (raw && !skillBlock && !/here is your score|ai match result|match analytics|your score is/i.test(raw)) {
    return raw;
  }
  const score = clampScore(analysis?.match_score ?? analysis?.matchScore ?? 0);
  const accept = clampScore(analysis?.acceptanceScore ?? analysis?.overallScore ?? score);
  const strengths = Array.isArray(analysis?.strengths)
    ? analysis.strengths
    : (Array.isArray(analysis?.matchedSkills) ? analysis.matchedSkills : []);
  const gaps = Array.isArray(analysis?.gaps)
    ? analysis.gaps
    : (Array.isArray(analysis?.missingSkills) ? analysis.missingSkills : []);
  const overlap = strengths.slice(0, 3).join(' & ') || 'the skills you listed';
  const gap = gaps[0] || '';
  const role = String(title || 'this brief').replace(/\s+/g, ' ').trim().slice(0, 72);
  const fit = score >= 80 ? 'high overlap' : score >= 60 ? 'solid overlap' : score >= 40 ? 'partial overlap' : 'thin overlap';
  let line = `${Math.round(score)}% fit. ${fit} on ${overlap}`;
  if (gap) line += `; the brief also asks for ${gap}`;
  line += `. Acceptance sits around ${Math.round(accept)}% if you lead with a first-week result`;
  if (gap) line += ` and cover ${gap} in one concrete example`;
  if (role) line += ` for ${role}`;
  return `${line}.`;
}

function updateMatchUi(analysis, title) {
  const safeScore = clampScore(analysis?.match_score ?? analysis?.matchScore ?? analysis?.compatibilityScore ?? lastScore ?? 0);
  const accept = clampScore(analysis?.acceptanceScore ?? analysis?.overallScore ?? safeScore);
  const label = analysis?.matchLabel && !/add skills/i.test(String(analysis.matchLabel))
    ? analysis.matchLabel
    : matchBand(safeScore);
  const message = humanMatchCopy(analysis, title);
  lastScore = safeScore;
  paintMonster(safeScore);
  paintPoach(title || lastTitle || lastJob.title, lastJob.description || '', lastJob.url || lastJobUrl || '');
  lastMatch = {
    label,
    strengths: Array.isArray(analysis?.strengths) ? analysis.strengths : (analysis?.matchedSkills || []),
    gaps: Array.isArray(analysis?.gaps) ? analysis.gaps : (analysis?.missingSkills || []),
    message,
    onboardingRequired: false,
    acceptanceScore: accept,
  };

  const banner = document.getElementById('matchBanner');
  const bannerScore = document.getElementById('matchBannerScore');
  const bannerLabel = document.getElementById('matchBannerLabel');
  if (banner) banner.classList.add('on');
  if (bannerScore) bannerScore.textContent = lastMatch.onboardingRequired ? '—' : `${safeScore}%`;
  if (bannerLabel) {
    bannerLabel.textContent = lastMatch.onboardingRequired
      ? (lastMatch.message || 'Add at least two skills in Settings.')
      : message;
  }

  const matchEmpty = document.getElementById('matchEmpty');
  const matchCard = document.getElementById('matchCard');
  matchEmpty?.classList.add('hidden');
  matchCard?.classList.add('on');
  const ring = document.getElementById('matchRing');
  const badgeEl = document.getElementById('matchBadge');
  if (badgeEl) badgeEl.textContent = lastMatch.onboardingRequired ? '—' : String(safeScore);
  ring?.style.setProperty('--p', String(lastMatch.onboardingRequired ? 0 : safeScore));
  const matchTitle = document.getElementById('matchTitle');
  const matchLabel = document.getElementById('matchLabel');
  if (matchTitle) matchTitle.textContent = title || lastTitle || 'Open job';
  if (matchLabel) {
    matchLabel.textContent = lastMatch.onboardingRequired
      ? lastMatch.message
      : `${safeScore}% fit · ~${accept}% acceptance`;
  }
  const strengths = document.getElementById('matchStrengths');
  const gaps = document.getElementById('matchGaps');
  if (strengths) strengths.innerHTML = chipHtml(lastMatch.strengths, 'ok');
  if (gaps) gaps.innerHTML = chipHtml(lastMatch.gaps, 'gap');
  const note = document.getElementById('matchNote');
  if (note) note.textContent = message;
}

function renderCvPreview(text) {
  const preview = document.getElementById('cvPreview');
  if (!preview) return;
  const raw = String(text || '').replace(/^\s*[-*_]{3,}\s*$/gm, '').trim();
  const lines = raw.split('\n');
  const html = lines.map((line, index) => {
    const trimmed = line.trim();
    if (!trimmed) return '';
    if (index === 0 && trimmed.length < 80 && !/^(professional summary|experience|education|skills)/i.test(trimmed)) {
      return `<div class="name">${escapeHtml(trimmed)}</div>`;
    }
    if (/^[A-Z][A-Z0-9 &/.-]{2,}$/.test(trimmed) || /^(professional summary|experience|education|skills|certifications)/i.test(trimmed)) {
      return `<h3>${escapeHtml(trimmed)}</h3>`;
    }
    return `${escapeHtml(line)}\n`;
  }).join('');
  preview.innerHTML = html || escapeHtml(raw);
}

function renderAnalysisResults(data, pageTitle, pageUrl) {
  const mode = data.detectedMode || data.type || 'JOB_PROPOSAL';
  const isJob = mode === 'JOB_PROPOSAL' || data.intent === 'JOB_POSTINGS';
  const isCv = mode === 'CV_EVALUATION' || data.intent === 'CANDIDATE_POOL';
  const isB2b = mode === 'B2B_COMMAND';
  const safeScore = clampScore(data.match_score ?? data.matchScore ?? data.compatibilityScore ?? data.overallScore ?? 0);
  lastTitle = cleanCardTitle(
    data.title || data.jobTitle || pageTitle || '',
    isJob ? 'Job posting' : isCv ? 'Candidate' : 'Company',
  );
  lastScore = safeScore;
  lastJob = {
    title: lastTitle,
    url: data.url || pageUrl || '',
    description: data.jobDescription || lastJob.description || '',
    skills: Array.isArray(data.requiredSkills) ? data.requiredSkills : lastJob.skills,
    budget: data.budget || lastJob.budget || '',
    clientHistory: data.clientHistory || lastJob.clientHistory || '',
  };
  const cvJobMeta = document.getElementById('cvJobMeta');
  if (cvJobMeta) {
    cvJobMeta.textContent = lastJob.title
      ? `Tailoring for: ${lastJob.title}`
      : 'No job detected. Open a job posting and scan.';
  }
  updateMatchUi(data, lastTitle);

  if (modeBadge) modeBadge.textContent = `⚡ Detected: ${data.platformLabel || (isJob ? 'Job Post' : isCv ? 'Candidate Profile' : 'B2B Lead')}`;
  if (badge) badge.textContent = `${safeScore}`;
  scoreRing?.style.setProperty('--p', String(safeScore));
  if (titleEl) titleEl.textContent = lastTitle || (isJob ? 'Job posting' : isCv ? 'Candidate' : 'Company');
  const jobRecord = data.structuredJob || {};
  const metaBits = [jobRecord.company, jobRecord.location, jobRecord.salary || data.budget].filter(Boolean);
  if (metaEl) metaEl.textContent = metaBits.join(' · ') || data.url || pageUrl || '';
  setActiveChannel(data.url || pageUrl || '');

  if (isJob) {
    if (scoreHeading) scoreHeading.textContent = 'Match';
    if (scoreLabel) scoreLabel.textContent = humanMatchCopy(data, lastTitle);
    if (painHeading) painHeading.textContent = 'Technical pain point';
    if (bodyHeading) bodyHeading.textContent = 'Generated proposal';
    if (painEl) painEl.textContent = data.painPoint || data.summary || 'No pain point returned.';
    lastProposal = String(data.proposalText || '').trim();
    lastOutreach = '';
    lastCandidate = null;
    lastJobUrl = String(data.url || pageUrl || '').trim();
    if (proposalEl) proposalEl.textContent = lastProposal || 'No proposal generated.';
    if (lastProposal) {
      void saveProposalRecord({
        id: `${Date.now()}`,
        title: lastTitle,
        url: lastJobUrl,
        text: lastProposal,
        score: safeScore,
        at: Date.now(),
      });
    }
  } else if (isB2b) {
    if (scoreHeading) scoreHeading.textContent = 'Lead score';
    if (scoreLabel) scoreLabel.textContent = `${safeScore}% outreach priority`;
    if (painHeading) painHeading.textContent = 'Executive summary';
    if (bodyHeading) bodyHeading.textContent = 'Cold outreach draft';
    if (painEl) painEl.textContent = data.executiveSummary || data.summary || 'No summary returned.';
    lastOutreach = String(data.outreach || data.proposalText || '').trim();
    lastProposal = lastOutreach;
    lastCandidate = null;
    lastJobUrl = '';
    const makers = Array.isArray(data.decisionMakers) && data.decisionMakers.length
      ? `\n\nDecision-makers: ${data.decisionMakers.join(', ')}`
      : '';
    if (proposalEl) proposalEl.textContent = `${lastOutreach}${makers}`.trim() || 'No outreach generated.';
  } else {
    if (scoreHeading) scoreHeading.textContent = 'Fit score';
    if (scoreLabel) scoreLabel.textContent = `${safeScore}% candidate fit`;
    if (painHeading) painHeading.textContent = 'Why this candidate';
    if (bodyHeading) bodyHeading.textContent = 'Evaluation';
    if (painEl) painEl.textContent = data.whyThisCandidate || data.painPoint || 'No rationale returned.';
    lastProposal = '';
    lastOutreach = '';
    lastJobUrl = '';
    lastCandidate = {
      title: data.title,
      role: data.role,
      url: data.url || pageUrl,
      summary: data.summary,
      score: safeScore,
      pros: data.pros || [],
      cons: data.cons || [],
    };
    const extras = [
      data.summary,
      Array.isArray(data.pros) && data.pros.length ? `Pros: ${data.pros.join('; ')}` : '',
      Array.isArray(data.cons) && data.cons.length ? `Watch: ${data.cons.join('; ')}` : '',
    ].filter(Boolean).join('\n\n');
    if (proposalEl) proposalEl.textContent = extras || 'Candidate parsed.';
  }

  actionsJob?.classList.toggle('hidden', !isJob);
  actionsDeploy?.classList.toggle('hidden', !isJob || !lastProposal);
  actionsCv?.classList.toggle('hidden', !isCv);
  actionsB2b?.classList.toggle('hidden', !isB2b);
  if (copyBtn) copyBtn.disabled = !isJob || !lastProposal;
  if (autofillBtn) autofillBtn.disabled = !isJob || !lastProposal;
  if (deployBtn) deployBtn.disabled = !isJob || !lastProposal;
  if (viewJobLink) {
    const href = /^https?:\/\//i.test(lastJobUrl) ? lastJobUrl : '';
    viewJobLink.href = href || 'https://sovereignapp.pro/apply-queue';
    const showLink = isJob && Boolean(href);
    viewJobLink.classList.toggle('hidden', !showLink);
    actionsJobLink?.classList.toggle('hidden', !showLink);
  }
  if (saveCandidateBtn) saveCandidateBtn.disabled = !isCv;
  if (outreachBtn) outreachBtn.disabled = !isB2b || !lastOutreach;
  card?.classList.add('on');
  const dispatchOut = document.getElementById('dispatchOutput');
  const dispatchActions = document.getElementById('dispatchActions');
  if (dispatchOut) {
    dispatchOut.textContent = lastProposal || lastOutreach || '';
    dispatchOut.classList.toggle('hidden', !(lastProposal || lastOutreach));
  }
  dispatchActions?.classList.toggle('hidden', !(lastProposal || lastOutreach));
  const leadCard = document.getElementById('leadCard');
  if (effectiveMode() === 'b2b' || isB2b) {
    leadCard?.classList.add('on');
    const leadTitle = document.getElementById('leadTitle');
    const leadMeta = document.getElementById('leadMeta');
    const leadClient = document.getElementById('leadClient');
    const leadMakers = document.getElementById('leadMakers');
    const leadOutreach = document.getElementById('leadOutreach');
    if (leadTitle) leadTitle.textContent = lastTitle || 'Lead';
    if (leadMeta) leadMeta.textContent = lastJobUrl || pageUrl || '';
    if (leadClient) leadClient.textContent = data.executiveSummary || data.clientHistory || data.painPoint || 'Client details captured from the open page.';
    if (leadMakers) {
      const makers = Array.isArray(data.decisionMakers) ? data.decisionMakers : [];
      leadMakers.textContent = makers.length ? makers.join(', ') : 'Not listed on this page.';
    }
    if (leadOutreach) leadOutreach.textContent = lastOutreach || lastProposal || '';
    void saveLeadRecord({
      id: `${Date.now()}`,
      title: lastTitle,
      url: lastJobUrl || pageUrl,
      text: lastOutreach || lastProposal || data.executiveSummary || '',
      at: Date.now(),
    });
  }
  setBusy(false, isJob ? 'Job analysis ready.' : isCv ? 'Candidate evaluation ready.' : 'B2B brief ready.');
  const leadStatus = document.getElementById('leadStatus');
  const dispatchStatus = document.getElementById('dispatchStatus');
  if (leadStatus) leadStatus.textContent = 'Lead captured. Copy outreach or open the B2B dashboard.';
  if (dispatchStatus) dispatchStatus.textContent = lastProposal ? 'Team pitch ready. Copy it. Sovereign never auto-submits.' : dispatchStatus.textContent;
}

function emptyPageData() {
  return {
    pageText: '',
    pageTitle: '',
    pageUrl: '',
    jobTitle: '',
    jobDescription: '',
    requiredSkills: [],
    budget: '',
    clientHistory: '',
    isolated: false,
    kind: 'job',
    contentType: '',
    discarded: false,
    discardReason: '',
    hash: '',
  };
}

function normalizePageData(raw, fallback = emptyPageData()) {
  const skills = Array.isArray(raw?.requiredSkills)
    ? raw.requiredSkills.map((item) => String(item)).filter(Boolean).slice(0, 16)
    : [];
  const normalized = {
    pageText: String(raw?.pageText || raw?.jobDescription || fallback.pageText || ''),
    pageTitle: String(raw?.jobTitle || raw?.pageTitle || fallback.pageTitle || ''),
    pageUrl: String(raw?.pageUrl || fallback.pageUrl || ''),
    jobTitle: String(raw?.jobTitle || raw?.pageTitle || fallback.jobTitle || ''),
    jobDescription: String(raw?.jobDescription || raw?.pageText || fallback.jobDescription || ''),
    requiredSkills: skills,
    budget: String(raw?.budget || raw?.structuredJob?.salary || fallback.budget || ''),
    clientHistory: String(raw?.clientHistory || raw?.structuredJob?.company || fallback.clientHistory || ''),
    isolated: Boolean(raw?.isolated),
    kind: raw?.kind || fallback.kind || 'job',
    contentType: raw?.contentType || fallback.contentType || '',
    discarded: Boolean(raw?.discarded),
    discardReason: String(raw?.discardReason || raw?.reason || fallback.discardReason || ''),
    hash: String(raw?.hash || raw?.signature || fallback.hash || ''),
    structuredJob: sanitizeStructuredJob(raw?.structuredJob),
    pageLanguage: String(raw?.pageLanguage || '').split('-')[0].toLowerCase(),
    analysis: raw?.analysis || null,
    autoAnalyzed: Boolean(raw?.autoAnalyzed),
    flushed: Boolean(raw?.flushed),
  };
  if (normalized.pageLanguage) rememberPageLanguage(normalized.pageLanguage);
  setActiveChannel(normalized.pageUrl);
  return normalized;
}

function flushJobContext() {
  lastProposal = '';
  lastOutreach = '';
  lastCv = '';
  lastCandidate = null;
  lastScore = 0;
  lastMatch = {
    label: '',
    strengths: [],
    gaps: [],
    message: '',
    onboardingRequired: false,
    acceptanceScore: 0,
  };
  lastJob = {
    title: '',
    url: '',
    description: '',
    skills: [],
    budget: '',
    clientHistory: '',
    kind: 'job',
    hash: '',
    contentType: '',
  };
  lastTitle = '';
  lastJobUrl = '';
  lastTargetHash = '';
  document.getElementById('poachBanner')?.classList.remove('on');
}

function showJobAutoFillHint(on) {
  document.getElementById('jobAutoFillHint')?.classList.toggle('hidden', !on);
}

function isRestrictedTabUrl(href) {
  return /^(chrome|edge|about|chrome-extension|moz-extension|devtools):/i.test(String(href || ''))
    || /chromewebstore\.google\.com|chrome\.google\.com\/webstore/i.test(String(href || ''));
}

function isJobBoardUrl(href) {
  return /upwork\.com|linkedin\.com|fiverr\.com|indeed\.com|glassdoor\.com/i.test(String(href || ''));
}

function setScanButton(state, title) {
  const btn = document.getElementById('rescan');
  if (!btn) return;
  if (state === 'scanning') btn.textContent = 'Scanning…';
  else if (state === 'live') {
    const name = String(title || '').replace(/\s+/g, ' ').trim().slice(0, 28);
    btn.textContent = name ? `Scanned · ${name}` : 'Scanned. Handle below';
  } else {
    btn.textContent = 'Scan Active Screen';
  }
}

function setTargetBadge(state, title, kind, contentType) {
  const el = document.getElementById('targetBadge');
  const text = document.getElementById('targetBadgeText');
  if (!el || !text) return;
  el.classList.toggle('live', state === 'live');
  el.classList.toggle('scanning', state === 'scanning');
  if (state === 'idle') {
    text.textContent = 'Open a job post, then scan.';
    setScanButton('idle');
    return;
  }
  if (contentType === 'CANDIDATE_LIST' || kind === 'list') {
    el.classList.remove('live');
    el.classList.add('scanning');
    text.textContent = '🟡 Open a single job or profile';
    return;
  }
  if (state !== 'live') {
    text.textContent = 'Scanning...';
    setScanButton('scanning');
    return;
  }
  const noun = kind === 'cv' || contentType === 'PROFILE_CV'
    ? 'CV'
    : kind === 'b2b'
      ? 'Lead'
      : 'Job';
  const name = String(title || noun).replace(/\s+/g, ' ').trim().slice(0, 72);
  text.textContent = `Active target: ${name}`;
  setScanButton('live', name);
}

function applyIsolatedJob(pageData) {
  lastJob = {
    title: pageData.jobTitle || pageData.pageTitle || '',
    url: pageData.pageUrl || '',
    description: pageData.jobDescription || pageData.pageText || '',
    skills: Array.isArray(pageData.requiredSkills) ? pageData.requiredSkills : [],
    budget: pageData.budget || '',
    clientHistory: pageData.clientHistory || '',
    kind: pageData.kind || 'job',
    hash: pageData.hash || '',
    contentType: pageData.contentType || '',
  };
  lastTitle = lastJob.title;
  lastJobUrl = lastJob.url;
  const cvJobMeta = document.getElementById('cvJobMeta');
  if (cvJobMeta) {
    cvJobMeta.textContent = lastJob.kind === 'cv'
      ? (lastJob.title ? `Profile on screen: ${lastJob.title}` : 'Profile isolated.')
      : (lastJob.title ? `Tailoring for: ${lastJob.title}` : 'No job isolated yet.');
  }
  if (titleEl) titleEl.textContent = lastJob.title || '';
  if (metaEl) metaEl.textContent = lastJob.url || '';
  paintPoach(lastJob.title, lastJob.description, lastJob.url);
  const instantJob = document.getElementById('instantJob');
  if (instantJob && String(lastJob.description || '').trim().length >= 40) {
    instantJob.value = lastJob.description;
    showJobAutoFillHint(true);
  }
}

async function refreshViewportAnalysis(pageData) {
  if (!assertAccountOpen()) return;
  applyIsolatedJob(pageData);
  setTargetBadge('live', lastJob.title, lastJob.kind);

  // Non-blocking onboarding hint: show a gentle nudge but continue with
  // effectiveSkillList() so the AI can still generate a proposal and score.
  const busyMsg = lastJob.kind === 'cv' ? 'Scoring the profile on screen…' : 'Scoring the job on screen…';
  setBusy(true, busyMsg);

  try {
    const data = await postParseDom(pageData, { scoreOnly: true });
    const merged = await enrichWithSmartMatch(pageData, data);
    updateMatchUi(merged, lastJob.title);
    if (scoreLabel) scoreLabel.textContent = humanMatchCopy(merged, lastJob.title);
    const score = Number(merged.match_score ?? merged.matchScore ?? 0);
    const safe = Math.max(0, Math.min(100, Math.round(score)));
    if (badge) badge.textContent = String(safe);
    scoreRing?.style.setProperty('--p', String(safe));
    card?.classList.add('on');
    if (modeBadge) {
      modeBadge.textContent = lastJob.kind === 'cv'
        ? '⚡ Detected: Candidate Profile'
        : lastJob.kind === 'b2b'
          ? '⚡ Detected: B2B Lead'
          : '⚡ Detected: Job Post';
    }
    setBusy(false, lastJob.kind === 'cv'
      ? 'Profile on screen is scored. Generate a tailored CV when you want a rewrite.'
      : `Scoring “${String(lastJob.title || 'this job').slice(0, 52)}”. Generate Proposal to rewrite for this brief.`);
  } catch (err) {
    const msg = err?.message || String(err);
    if (/Failed to fetch|NetworkError|redirect|CORS|preflight|OPENAI|Vercel|API_KEY/i.test(msg)) {
      setBusy(false, 'Target updated. Scoring will retry on the next pause.');
      return;
    }
    setBusy(false, publicError(msg));
  }
}

function applyReadyAnalysis(pageData, analysis) {
  applyIsolatedJob(pageData);
  setTargetBadge('live', lastJob.title, lastJob.kind, lastJob.contentType);
  if (!analysis) return;
  updateMatchUi(analysis, lastJob.title);
  if (scoreLabel) scoreLabel.textContent = humanMatchCopy(analysis, lastJob.title);
  const score = Number(analysis.match_score ?? analysis.matchScore ?? 0);
  const safe = Math.max(0, Math.min(100, Math.round(score)));
  if (badge) badge.textContent = String(safe);
  scoreRing?.style.setProperty('--p', String(safe));
  card?.classList.add('on');
  if (modeBadge) {
    modeBadge.textContent = lastJob.kind === 'cv' || pageData.contentType === 'PROFILE_CV'
      ? '⚡ Detected: Candidate Profile'
      : lastJob.kind === 'b2b'
        ? '⚡ Detected: B2B Lead'
        : '⚡ Detected: Job Post';
  }
  setBusy(false, lastJob.kind === 'cv'
    ? 'Profile on screen is scored. Generate a tailored CV when you want a rewrite.'
    : `Scoring “${String(lastJob.title || 'this job').slice(0, 52)}”. Generate Proposal to rewrite for this brief.`);
}

function onViewportFocus(raw) {
  if (!raw) return;
  if (raw.flushed && !raw.pageText && !raw.jobDescription && !raw.analysis) {
    clearTimeout(viewportScoreTimer);
    flushJobContext();
    setTargetBadge('scanning');
    return;
  }
  const pageData = normalizePageData(raw);
  if (pageData.discarded || pageData.contentType === 'CANDIDATE_LIST' || pageData.kind === 'list') {
    clearTimeout(viewportScoreTimer);
    flushJobContext();
    lastTargetHash = pageData.hash || 'list';
    setTargetBadge('scanning', '', 'list', 'CANDIDATE_LIST');
    if (proposalEl) {
      proposalEl.textContent = pageData.discardReason === 'no-center-card'
        ? 'Scroll a job card to the center of the screen, then click Scan.'
        : pageData.discardReason === 'chrome'
          ? 'Ignored UI chrome (menus, translate, banners). Focus a job or profile.'
          : 'This looks like a list. Open one job or profile to score it.';
    }
    setBusy(false, pageData.discardReason === 'no-center-card'
      ? 'No job card in viewport center. Scroll so a job description fills the screen.'
      : pageData.discardReason === 'chrome'
        ? 'Focus the job description, not the page chrome.'
        : 'Open a single job or profile in the viewport.');
    return;
  }
  if (!pageData.pageText && !pageData.jobDescription) return;
  const hash = pageData.hash || '';
  // Only deduplicate if the hash AND title BOTH match and this is not a freshly
  // flushed payload. A title mismatch means the page changed even if the hash
  // somehow collided (e.g. same hash across SPA navigations).
  if (hash && hash === lastTargetHash && !raw.flushed
    && (pageData.jobTitle || '') === (lastJob.title || '')) {
    clearTimeout(viewportScoreTimer);
    if (raw.analysis) applyReadyAnalysis(pageData, raw.analysis);
    else setTargetBadge('live', pageData.jobTitle || lastJob.title, pageData.kind, pageData.contentType);
    return;
  }
  if (hash && lastTargetHash && hash !== lastTargetHash) {
    flushJobContext();
    if (proposalEl) {
      proposalEl.textContent = pageData.kind === 'cv'
        ? 'Profile changed. Generate a tailored CV for this document.'
        : 'Target changed. Generate Proposal to write for this brief.';
    }
  }
  lastTargetHash = hash;
  applyIsolatedJob(pageData);
  setTargetBadge(raw.analysis ? 'live' : 'scanning', pageData.jobTitle, pageData.kind, pageData.contentType);
  if (raw.analysis) {
    applyReadyAnalysis(pageData, raw.analysis);
    return;
  }
  if (analyzing || generatingCv) return;
  clearTimeout(viewportScoreTimer);
  viewportScoreTimer = setTimeout(() => {
    void refreshViewportAnalysis(pageData);
  }, 420);
}

async function getActiveTabDOM() {
  const scraped = await chrome.runtime.sendMessage({ type: 'SCRAPE_ACTIVE_TAB' }).catch((err) => {
    throw new Error(err?.message || 'Could not read the active tab.');
  });
  if (scraped?.success && scraped.data) return normalizePageData(scraped.data);
  throw new Error(scraped?.error || 'Could not isolate the open job.');
}

async function postParseDom(pageData, options = {}) {
  const deep = canUseDeepMatch();
  const payload = {
    pageText: pageData.pageText,
    pageTitle: pageData.pageTitle,
    pageUrl: pageData.pageUrl,
    text: pageData.pageText,
    sourceUrl: pageData.pageUrl,
    jobTitle: pageData.jobTitle,
    jobDescription: pageData.jobDescription || pageData.pageText,
    requiredSkills: pageData.requiredSkills || [],
    budget: pageData.budget,
    clientHistory: pageData.clientHistory,
    // structuredJob carries the clean, field-isolated extraction from scraper.js.
    structuredJob: pageData.structuredJob || null,
    company: pageData.structuredJob?.company || '',
    location: pageData.structuredJob?.location || '',
    salary: pageData.structuredJob?.salary || '',
    skills: effectiveSkillList(),
    experience: settings.pastWins || settings.experience,
    profession: settings.profession || '',
    hourlyRate: Number(settings.hourlyRate) || undefined,
    portfolio: settings.portfolio || '',
    pastWins: settings.pastWins || '',
    matchDepth: deep ? 'deep' : 'basic',
    deepMatch: deep,
    scoreOnly: Boolean(options.scoreOnly),
    analysisMode: options.analysisMode || '',
    uploadedText: options.uploadedText || '',
    ...languagePayload(options.uploadedText || pageData.jobDescription || pageData.pageText),
  };

  const viaWorker = await chrome.runtime.sendMessage({
    type: 'PARSE_DOM',
    apiBase: apiBase(),
    payload,
  }).catch(() => null);

  if (viaWorker?.success && viaWorker.data) return viaWorker.data;
  if (viaWorker?.error) {
    if (/guest_limit/i.test(String(viaWorker.error))) {
      settings._guestUsed = 2;
      showGuestGate();
    }
    throw new Error(viaWorker.error);
  }

  const guest = settings.accountEmail ? null : await guestState();
  const response = await fetch(`${PARSE_DOM_URL}?t=${Date.now()}`, {
    method: 'POST',
    cache: 'no-store',
    headers: {
      'Content-Type': 'application/json',
      'x-extension-id': chrome.runtime.id || '',
      ...(guest ? { 'x-sovereign-guest': guest.token || guest.id } : {}),
    },
    body: JSON.stringify(payload),
  });

  const data = await response.json().catch(() => ({}));
  if (response.status === 401 && (data.gate || data.error === 'guest_limit')) {
    settings._guestUsed = 2;
    showGuestGate();
    throw new Error(data.message || 'guest_limit');
  }
  if (!response.ok) {
    console.error('[Sovereign] parse-dom HTTP', response.status, data);
    if (response.status === 401) throw new Error('Session expired, please sign in');
    if (response.status === 408 || response.status === 429 || response.status >= 500) {
      throw new Error('Connection timeout. Retrying.');
    }
    throw new Error(data.message || data.error || `Server returned ${response.status}`);
  }
  return data;
}

function gapLabels(items) {
  if (!Array.isArray(items)) return [];
  return items.map((item) => {
    if (typeof item === 'string') return item;
    return String(item?.area || item?.detail || '').trim();
  }).filter(Boolean).slice(0, 6);
}

async function enrichWithSmartMatch(pageData, data) {
  if (!canUseDeepMatch() || data?.onboardingRequired) return data;
  const payload = {
    intent: 'smart-match',
    jobDescription: pageData.jobDescription || pageData.pageText,
    jobTitle: pageData.jobTitle || pageData.pageTitle,
    skills: effectiveSkillList(),
    experience: settings.experience,
    hourlyRate: Number(settings.hourlyRate) || undefined,
    budget: pageData.budget,
    requiredSkills: pageData.requiredSkills || [],
    clientHistory: pageData.clientHistory,
    matchDepth: 'deep',
    deepMatch: true,
  };
  const viaWorker = await chrome.runtime.sendMessage({
    type: 'SMART_MATCH',
    apiBase: apiBase(),
    payload,
  }).catch(() => null);
  const smart = viaWorker?.success ? viaWorker.data : null;
  if (!smart) return data;
  const extraTip = Array.isArray(smart.applicationTips) ? String(smart.applicationTips[0] || '').trim() : '';
  const banned = /here is your score|ai match result|your score is/i;
  const narrative = String(data.matchNarrative || data.matchMessage || smart.matchNarrative || '').trim();
  const withTip = extraTip && !banned.test(extraTip) ? `${narrative} ${extraTip}`.trim() : narrative;
  return {
    ...data,
    match_score: data.match_score ?? data.matchScore,
    matchScore: data.matchScore ?? data.match_score,
    acceptanceScore: data.acceptanceScore,
    overallScore: data.acceptanceScore ?? data.overallScore,
    strengths: (Array.isArray(data.strengths) && data.strengths.length)
      ? data.strengths
      : gapLabels(smart.gapAnalysis?.strengths),
    gaps: (Array.isArray(data.gaps) && data.gaps.length)
      ? data.gaps
      : gapLabels(smart.gapAnalysis?.gaps),
    matchMessage: withTip,
    matchNarrative: withTip,
  };
}

function assertAccountOpen() {
  if (isExtensionAdmin()) return true;
  if (!settings.accountEmail) return true;
  if (settings.isAppsumoUser) {
    if (Number(settings.remainingCredits || 0) <= 0) showCreditResetBanner();
    return true;
  }
  const status = String(settings.subscriptionStatus || '').toLowerCase();
  if (['canceled', 'cancelled', 'expired', 'past_due', 'unpaid', 'paused'].includes(status)) {
    showPaywall('renew');
    setBusy(false, 'Renew your subscription to keep using the extension.');
    return false;
  }
  return true;
}

async function analyzeActivePage() {
  if (analyzing) return;
  if (!assertGenerationAllowed()) return;
  card?.classList.remove('on');
  lastProposal = '';
  lastOutreach = '';
  lastCandidate = null;
  lastJobUrl = '';
  hideErrorBadge();
  setBusy(true, 'Reading the active tab…');

  try {
    const pageData = await getActiveTabDOM();
    lastJob = {
      title: pageData.jobTitle || pageData.pageTitle,
      url: pageData.pageUrl,
      description: pageData.jobDescription || pageData.pageText,
      skills: pageData.requiredSkills || [],
      budget: pageData.budget || '',
      clientHistory: pageData.clientHistory || '',
      kind: pageData.kind || 'job',
      hash: pageData.hash || '',
    };
    lastTargetHash = pageData.hash || lastTargetHash;
    setTargetBadge('live', lastJob.title, lastJob.kind);
    const pageText = String(pageData.jobDescription || pageData.pageText || '').trim();
    if (pageText.length < 20) {
      throw new Error('This tab does not have enough readable text to analyze.');
    }

    setBusy(true, pageData.isolated ? 'Analyzing the job on screen…' : 'Analyzing the visible page…');
    const data = await postParseDom(pageData);
    const merged = await enrichWithSmartMatch(pageData, data);
    void ingestOpportunity(pageData, merged);
    renderAnalysisResults(
      { ...merged, structuredJob: pageData.structuredJob || merged?.structuredJob || null },
      pageData.pageTitle,
      pageData.pageUrl,
    );
    void noteAiSuccess();
    if (!settings.accountEmail && (merged.proposalText || merged.outreach || merged.summary)) {
      void recordGuestUse(merged.guestToken);
    }
  } catch (err) {
    console.error('DOM Extraction / API Error:', err);
    const msg = err?.message || String(err);
    if (/guest_limit/i.test(msg)) {
      showGuestGate();
      setBusy(false, 'Sign in to keep generating.');
      return;
    }
    if (/Failed to fetch|NetworkError|redirect|CORS|preflight|OPENAI|Vercel|API_KEY/i.test(msg)) {
      showError('Service temporarily busy. Please try again in a few moments.');
      return;
    }
    if (/permission to access the respective host/i.test(msg)) {
      showError('Reload the extension, then try Analyze again.');
      return;
    }
    showError(msg);
  }
}

async function rescanActiveScreen() {
  // Release any stuck lock — a deliberate click always wins.
  analyzing = false;
  const thisSeq = ++scanSeq;
  const scanStarted = Date.now();
  const SCAN_WINDOW_MS = 9000;
  const remainingMs = () => Math.max(0, SCAN_WINDOW_MS - (Date.now() - scanStarted));

  if (!assertAccountOpen()) return;
  if (!isExtensionAdmin() && settings.accountEmail && (settings.canGenerate === false || Number(settings.remainingCredits || 0) <= 0)) {
    if (settings.isAppsumoUser) showCreditResetBanner();
    else showPaywall('credits');
    setTargetBadge('idle');
    setBusy(false, settings.isAppsumoUser
      ? APPSUMO_ZERO_MESSAGE
      : 'Your monthly credits are used up. Upgrade to keep scanning.');
    return;
  }

  // Flush ALL stale state so nothing from a previous job bleeds in.
  clearTimeout(viewportScoreTimer);
  lastTargetHash = '';
  lastJob = {
    title: '', url: '', description: '', skills: [],
    budget: '', clientHistory: '', kind: 'job', hash: '', contentType: '',
  };
  // CRITICAL: zero the match score immediately so the old value (e.g. 17%)
  // never lingers on screen while the fresh analysis is in-flight.
  lastScore = 0;
  lastMatch = { label: '', strengths: [], gaps: [], message: '', onboardingRequired: false, acceptanceScore: 0 };
  if (badge) { badge.textContent = '0'; }
  if (scoreRing) scoreRing.style.setProperty('--p', '0');
  if (card) card.classList.remove('on');
  if (scoreLabel) scoreLabel.textContent = '';
  // Wipe the cached viewport from storage immediately — this prevents the
  // chrome.storage.onChanged listener from re-hydrating stale data while
  // the fresh DOM scrape is in-flight.
  try {
    void chrome.storage.local.set({
      [STORE.VIEWPORT]: { scanning: true, flushed: true, at: Date.now() },
    });
  } catch {/**/ }

  hideErrorBadge();
  setTargetBadge('scanning');
  setBusy(true, 'Scanning active screen…');
  analyzing = true;

  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab?.id) {
      const reply = await chrome.tabs.sendMessage(tab.id, { type: 'DETECT_PAGE_LANGUAGE' }).catch(() => null);
      if (reply?.target_language) rememberPageLanguage(reply.target_language);
    }
  } catch { /**/ }

  try {
    const scrapeBudget = Math.min(6000, remainingMs());
    const forced = scrapeBudget < 400
      ? null
      : await withTimeout(
        chrome.runtime.sendMessage({ type: 'SCAN_ACTIVE_SCREEN' }).catch(() => null),
        scrapeBudget,
      ).catch(() => null);

    if (thisSeq !== scanSeq) return; // newer click superseded this scan

    // If background timed out or failed, do a direct scrape without LLM pre-baking.
    const fallbackBudget = Math.min(4000, remainingMs());
    const pageData = forced?.success && forced.data
      ? normalizePageData(forced.data)
      : fallbackBudget < 400
        ? null
        : await withTimeout(getActiveTabDOM(), fallbackBudget).catch(() => null);

    if (thisSeq !== scanSeq) return;

    if (!pageData) {
      setBusy(false, 'Open a job post on LinkedIn, Upwork, or any webpage to scan.');
      analyzing = false;
      return;
    }

    // Discarded (no center card, chrome noise, list, empty).
    if (pageData.discarded) {
      flushJobContext();
      setTargetBadge('idle');
      const discardMsg = pageData.discardReason === 'non-job'
        ? 'No target detected. Navigate to an active job listing.'
        : pageData.discardReason === 'no-center-card'
        ? 'Scroll a job card to the center of the screen, then click Scan again.'
        : pageData.discardReason === 'chrome'
          ? 'Focus the job description. The translate widget or nav was ignored.'
          : 'This looks like a list. Open one job to score it.';
      setBusy(false, discardMsg);
      if (proposalEl) proposalEl.textContent = discardMsg;
      analyzing = false;
      return;
    }

    const pageText = String(pageData.jobDescription || pageData.pageText || '').trim();
    if (pageText.length < 20) {
      analyzing = false;
      throw new Error('This tab does not have enough readable text to analyze.');
    }

    // Commit the scraped job context immediately so the UI reflects the new target.
    lastJob = {
      title: pageData.jobTitle || pageData.pageTitle || '',
      url: pageData.pageUrl || '',
      description: pageData.jobDescription || pageData.pageText || '',
      skills: pageData.requiredSkills || [],
      budget: pageData.budget || '',
      clientHistory: pageData.clientHistory || '',
      kind: pageData.kind || 'job',
      hash: pageData.hash || '',
      contentType: pageData.contentType || '',
    };
    lastTargetHash = pageData.hash || '';
    setTargetBadge('live', lastJob.title, lastJob.kind);
    const instantJob = document.getElementById('instantJob');
    if (instantJob && lastJob.description) {
      instantJob.value = lastJob.description;
      showJobAutoFillHint(true);
    }
    const cvJobMeta = document.getElementById('cvJobMeta');
    if (cvJobMeta) cvJobMeta.textContent = lastJob.kind === 'cv'
      ? (lastJob.title ? `Profile on screen: ${lastJob.title}` : 'Profile isolated.')
      : (lastJob.title ? `Tailoring for: ${lastJob.title}` : 'No job isolated yet.');
    if (titleEl) titleEl.textContent = lastJob.title || '';

    // Use the analysis the background already computed — ZERO extra network calls.
    // IMPORTANT: only recycle the background's pre-baked analysis when its hash
    // matches the hash of the page we JUST scraped. A mismatch means the background
    // returned a stale cached result for the previous job — discard it and call
    // postParseDom fresh so we never show an old score (e.g. the stuck 17%).
    let merged;
    const pre = forced?.data?.analysis;
    const preHash = String(forced?.data?.hash || forced?.data?.signature || '').trim();
    const freshHash = String(pageData.hash || pageData.signature || '').trim();
    const preIsValid = pre
      && !pre.discarded
      && preHash
      && preHash === freshHash
      && (pre.matchScore !== undefined || pre.match_score !== undefined);

    if (preIsValid) {
      merged = pre;
    } else {
      if (thisSeq !== scanSeq) return;
      const analysisBudget = remainingMs();
      merged = analysisBudget < 800
        ? null
        : await withTimeout(
        postParseDom(pageData, { scoreOnly: true }),
        analysisBudget,
      ).catch((err) => {
        if (err?.message === 'timeout') return null;
        throw err;
      });
    }

    if (thisSeq !== scanSeq) return;

    const profileText = [settings.skills, settings.experience].filter(Boolean).join('\n');
    const localFit = scoreOverlap(pageText, profileText);
    merged = {
      ...(merged || {}),
      matchScore: localFit.match,
      match_score: localFit.match,
      acceptanceScore: localFit.cv,
      matchedSkills: localFit.matched,
      missingSkills: localFit.missing,
      strengths: localFit.matched,
      gaps: localFit.missing,
      matchNarrative: localFit.breakdown,
      matchMessage: localFit.breakdown,
    };

    updateMatchUi(merged, lastJob.title || pageData.pageTitle);
    if (titleEl && lastJob.title) titleEl.textContent = lastJob.title;
    if (scoreLabel) scoreLabel.textContent = humanMatchCopy(merged, lastJob.title);
    const score = clampScore(merged.match_score ?? merged.matchScore ?? 0);
    if (badge) badge.textContent = String(score);
    scoreRing?.style.setProperty('--p', String(score));
    setBusy(false, pageData.isolated
      ? `Scoring "${String(lastJob.title || 'this job').slice(0, 52)}". Ready to handle.`
      : 'Scanned. Open the job detail pane and scan again for a tighter read.');
  } catch (err) {
    if (thisSeq !== scanSeq) return;
    const msg = err?.message || String(err);
    if (/timeout/i.test(msg)) {
      setBusy(false, 'Connection timeout. Retrying.');
    } else if (/Failed to fetch|NetworkError|redirect|CORS|preflight|OPENAI|Vercel|API_KEY/i.test(msg)) {
      showError('Connection timeout. Retrying.');
    } else if (/permission to access the respective host/i.test(msg)) {
      showError('Reload the extension, then scan again.');
    } else {
      showError(publicError(msg));
    }
  } finally {
    if (thisSeq === scanSeq) {
      analyzing = false;
      const badgeEl = document.getElementById('targetBadge');
      if (badgeEl?.classList.contains('scanning')) setTargetBadge('idle');
    }
  }
}

function applyTheme(theme) {
  const next = theme === 'oled' ? 'oled' : 'obsidian';
  document.body.dataset.theme = next;
  document.getElementById('themeOled')?.classList.toggle('on', next === 'oled');
  document.getElementById('themeObsidian')?.classList.toggle('on', next === 'obsidian');
}

function applyMembership(plan) {
  const next = plan === 'pro' || plan === 'appsumo' ? plan : 'unknown';
  document.getElementById('planPro')?.classList.toggle('on', next === 'pro');
  document.getElementById('planLtd')?.classList.toggle('on', next === 'appsumo');
  if (planStatus) {
    planStatus.textContent = next === 'pro'
      ? 'Membership: Pro subscription.'
      : next === 'appsumo'
        ? 'Membership: lifetime plan.'
        : 'Membership: not set on this device.';
  }
}

function applyAdminUi() {
  const admin = isExtensionAdmin();
  document.getElementById('adminDiagnostics')?.classList.toggle('hidden', !admin);
  if (apiBadge) apiBadge.classList.toggle('hidden', !admin);
}

function applyWorkspaceUi() {
  const mode = effectiveMode();
  const slider = document.getElementById('adminSlider');
  if (slider) slider.dataset.mode = mode;
  slider?.querySelectorAll('button[data-mode]').forEach((btn) => {
    const on = btn.dataset.mode === mode;
    btn.classList.toggle('on', on);
    btn.setAttribute('aria-selected', on ? 'true' : 'false');
    btn.setAttribute('tabindex', on ? '0' : '-1');
  });
  document.getElementById('navB2c')?.classList.toggle('hidden', mode !== 'b2c');
  document.getElementById('navB2b')?.classList.toggle('hidden', mode !== 'b2b');
  document.getElementById('headerUpload')?.classList.toggle('hidden', mode !== 'b2b');
  const scanRow = document.querySelector('.scan-actions');
  if (scanRow) scanRow.style.gridTemplateColumns = mode === 'b2b' ? '1fr 1fr' : '1fr';
  try { applyCreditBadge(); } catch (err) { console.error('[sovereign] credit badge', err); }
  const current = document.querySelector('.tab-view.on')?.id?.replace('tab-', '');
  const allowed = mode === 'b2b'
    ? ['candidate', 'b2b-proposal', 'lead', 'dispatch', 'team', 'settings']
    : ['instant', 'proposal', 'cv', 'match', 'settings'];
  if (!allowed.includes(current)) switchTab(allowed[0]);
  else {
    document.querySelectorAll('#navB2c button, #navB2b button').forEach((btn) => {
      btn.classList.toggle('on', btn.dataset.tab === current);
    });
  }
  try { syncGuideBanner(); } catch (err) { console.error('[sovereign] guide banner', err); }
}

function fillSettingsForm() {
  const skills = document.getElementById('skills');
  const hourlyRate = document.getElementById('hourlyRate');
  const fixedRate = document.getElementById('fixedRate');
  const experience = document.getElementById('experience');
  const accountEmail = document.getElementById('accountEmail');
  const outputLanguage = document.getElementById('outputLanguage');
  if (skills) skills.value = settings.skills || '';
  if (hourlyRate) hourlyRate.value = settings.hourlyRate || '';
  if (fixedRate) fixedRate.value = settings.fixedRate || '';
  if (experience) experience.value = settings.experience || 'mid';
  if (accountEmail) accountEmail.value = settings.accountEmail || '';
  const referralLink = document.getElementById('referralLink');
  const referralLine = document.getElementById('referralLine');
  const refUrl = referralUrl();
  if (referralLink) referralLink.value = refUrl;
  if (referralLine) {
    referralLine.textContent = refUrl
      ? refUrl
      : 'Sign in on Sovereign to get your referral link.';
  }
  if (outputLanguage) {
    outputLanguage.value = settings.languageChoice === 'auto'
      ? 'auto'
      : (settings.outputLanguage && settings.outputLanguage !== 'auto' ? settings.outputLanguage : 'en');
  }
  applyPlanChrome();
  applyTheme(settings.theme);
  applyMembership(settings.membership);
  applyAdminUi();
  applyWorkspaceUi();
}

function applyPlanChrome() {
  const pricing = document.getElementById('pricingLink');
  const billing = document.getElementById('billingLink');
  const note = document.getElementById('planStatus');
  const lapsed = subscriptionLapsed();
  const top = isTopActiveTier();
  if (pricing) pricing.hidden = Boolean(top && !lapsed);
  document.querySelectorAll('[data-upgrade]').forEach((el) => {
    el.hidden = Boolean(top && !lapsed);
  });
  if (billing) billing.textContent = lapsed ? 'Renew plan' : 'Billing';
  if (note && lapsed) note.textContent = 'This subscription has ended. Renew to restore premium tools.';
}

let settingsRevision = 0;
let settingsSaveChain = Promise.resolve();

async function persistSettings(partial) {
  const revision = ++settingsRevision;
  settings = { ...settings, ...partial, _settingsRev: revision };
  try { applyWorkspaceUi(); } catch (err) { console.error('[sovereign] workspace ui', err); }
  try { fillSettingsForm(); } catch (err) { console.error('[sovereign] settings ui', err); }
  const snapshot = settings;
  const write = settingsSaveChain
    .catch(() => undefined)
    .then(() => withTimeout(storageSet(STORE.SETTINGS, snapshot), 2500, 'Save took too long. Try again.'));
  settingsSaveChain = write.catch(() => undefined);
  try {
    await write;
  } catch (err) {
    console.error('[sovereign] save settings', err);
  }
}

function closestControl(event, selector) {
  const node = event?.target;
  const el = node && node.nodeType === 1 ? node : node?.parentElement;
  try {
    return el?.closest?.(selector) || null;
  } catch {
    return null;
  }
}

function setWorkspaceMode(mode) {
  const next = mode === 'b2b' ? 'b2b' : 'b2c';
  if (settings.workspaceMode === next) {
    try { applyWorkspaceUi(); } catch (err) { console.error('[sovereign] workspace ui', err); }
    return;
  }
  void persistSettings({ workspaceMode: next, workspace: 'dual' });
}

function setApiStatus(ok, detail) {
  const connectionStatus = document.getElementById('connectionStatus');
  if (connectionStatus) {
    connectionStatus.textContent = ok ? 'UP (Connected)' : 'Service temporarily busy';
    connectionStatus.style.color = ok ? '#10B981' : '#EF4444';
  }
  if (!isExtensionAdmin()) return;
  const statusElLocal = document.getElementById('api-status');
  if (apiBadge) {
    apiBadge.textContent = ok ? 'UP' : 'DOWN';
    apiBadge.classList.toggle('live', ok);
    apiBadge.classList.toggle('down', !ok);
  }
  if (apiStatusDetail) apiStatusDetail.textContent = detail;
  if (statusElLocal && statusElLocal !== apiStatusDetail) {
    statusElLocal.textContent = ok ? 'UP (Connected)' : 'DOWN';
    statusElLocal.style.color = ok ? '#10B981' : '#EF4444';
  }
}

async function pingApi() {
  const connectionStatus = document.getElementById('connectionStatus');
  if (connectionStatus) {
    connectionStatus.textContent = 'Checking connection…';
    connectionStatus.style.color = '';
  }
  if (isExtensionAdmin() && apiBadge) {
    apiBadge.textContent = 'API…';
    apiBadge.classList.remove('live', 'down');
  }
  if (isExtensionAdmin() && apiStatusDetail) {
    apiStatusDetail.textContent = `Checking ${PARSE_DOM_URL} …`;
  }
  try {
    const viaWorker = await chrome.runtime.sendMessage({ type: 'PING_API' }).catch(() => null);
    if (viaWorker?.success && viaWorker.data?.ok) {
      setApiStatus(true, `UP (Connected) via ${viaWorker.data.method || 'GET'} · ${PARSE_DOM_URL}`);
      return true;
    }
    throw new Error(viaWorker?.error || 'API unreachable');
  } catch (err) {
    setApiStatus(false, err?.message || 'Could not reach the parse-dom API.');
    return false;
  }
}

let b2bBlock = 'candidate';
const b2bBlocks = {
  candidate: { fileName: '', text: '', result: null, error: '', phase: '' },
  proposal: { fileName: '', text: '', result: null, error: '', phase: '' },
};
const b2bRunSeq = { candidate: 0, proposal: 0 };

function switchTab(tab) {
  try {
    const mode = effectiveMode();
    const allowed = mode === 'b2b'
      ? ['candidate', 'b2b-proposal', 'lead', 'dispatch', 'team', 'settings']
      : ['instant', 'proposal', 'cv', 'match', 'settings'];
    const id = allowed.includes(tab) ? tab : allowed[0];
    if (id === 'candidate' || id === 'b2b-proposal') {
      b2bBlock = id === 'b2b-proposal' ? 'proposal' : 'candidate';
      renderContextDrawer();
    }
    document.querySelectorAll('.tab-view').forEach((view) => {
      view.classList.toggle('on', view.id === `tab-${id}`);
    });
    document.querySelectorAll('#navB2c button, #navB2b button').forEach((btn) => {
      btn.classList.toggle('on', btn.dataset.tab === id);
    });
    if (id === 'settings') {
      void pingApi().catch((err) => console.error('[sovereign] ping', err));
      void Promise.resolve().then(() => renderSettingsHistory()).catch((err) => console.error('[sovereign] history', err));
    }
  } catch (err) {
    console.error('[sovereign] switch tab', err);
  }
}

document.getElementById('navB2c')?.addEventListener('click', (event) => {
  const btn = closestControl(event, 'button[data-tab]');
  if (!btn) return;
  switchTab(btn.dataset.tab);
});
document.getElementById('navB2b')?.addEventListener('click', (event) => {
  const btn = closestControl(event, 'button[data-tab]');
  if (!btn) return;
  switchTab(btn.dataset.tab);
});

(function bindModeSlider() {
  const slider = document.getElementById('adminSlider');
  if (!slider || slider.dataset.bound === '1') return;
  slider.dataset.bound = '1';
  const choose = (raw) => {
    try {
      setWorkspaceMode(raw === 'b2b' ? 'b2b' : 'b2c');
    } catch (err) {
      console.error('[sovereign] workspace switch', err);
    }
  };
  slider.querySelectorAll('button[data-mode]').forEach((btn) => {
    btn.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      choose(btn.dataset.mode);
    });
  });
  slider.addEventListener('keydown', (event) => {
    if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight' && event.key !== 'Enter' && event.key !== ' ') return;
    event.preventDefault();
    if (event.key === 'ArrowRight') choose('b2b');
    else if (event.key === 'ArrowLeft') choose('b2c');
    else {
      const btn = closestControl(event, 'button[data-mode]');
      if (btn) choose(btn.dataset.mode);
    }
  });
})();

document.getElementById('rescan')?.addEventListener('click', () => {
  // Cancel any queued viewport timer so a previous slow scan can't race this one.
  clearTimeout(viewportScoreTimer);
  analyzing = false;
  void rescanActiveScreen();
});

analyzeBtn?.addEventListener('click', () => {
  void analyzeActivePage();
});

copyBtn?.addEventListener('click', async () => {
  if (!lastProposal) return;
  await copyText(lastProposal);
  setBusy(false, 'Proposal copied. Paste it yourself on the original job post. Sovereign never auto-submits.');
});

function injectProposalPayload() {
  return {
    type: 'INJECT_PROPOSAL',
    proposalText: lastProposal,
    hourlyRate: settings.hourlyRate || '',
    fixedRate: settings.fixedRate || '',
    skills: settings.skills || '',
    pastWins: settings.pastWins || '',
  };
}

async function deployProposalToPage(statusReady) {
  if (!lastProposal) return;
  setBusy(true, 'Deploying proposal into the page editor…');
  try {
    const result = await chrome.runtime.sendMessage(injectProposalPayload());
    if (!result?.success) {
      setBusy(false, 'Open the cover letter box on this page, then tap Deploy again. Sovereign never auto-submits.');
      return;
    }
    setBusy(false, statusReady || 'Proposal inserted. Review and send on the platform. Sovereign never auto-submits.');
  } catch (err) {
    setBusy(false, publicError(err.message || String(err)));
  }
}

autofillBtn?.addEventListener('click', () => {
  void deployProposalToPage('Proposal inserted. Review it, then submit yourself. Sovereign never auto-sends.');
});
deployBtn?.addEventListener('click', () => {
  void deployProposalToPage();
});

saveCandidateBtn?.addEventListener('click', async () => {
  if (!lastCandidate) return;
  const blob = [
    lastCandidate.title || 'Candidate',
    lastCandidate.role || '',
    lastCandidate.url || '',
    `Fit ${lastCandidate.score}%`,
    lastCandidate.summary || '',
  ].filter(Boolean).join('\n');
  await copyText(blob);
  await saveCandidateRecord({
    id: `${Date.now()}`,
    title: lastCandidate.title || 'Candidate',
    role: lastCandidate.role || '',
    url: lastCandidate.url || '',
    summary: blob,
    score: lastCandidate.score || 0,
    at: Date.now(),
  });
  chrome.tabs.create({ url: `${CANONICAL_API}/talent-pool` }).catch(() => {});
  setBusy(false, 'Candidate saved locally and copied. Opening Sovereign B2B…');
});

outreachBtn?.addEventListener('click', async () => {
  if (!lastOutreach) return;
  await copyText(lastOutreach);
  setBusy(false, 'Cold outreach copied to clipboard.');
});

proposalListEl?.addEventListener('click', async (event) => {
  const copyId = event.target.closest('[data-copy]')?.getAttribute('data-copy');
  const deleteId = event.target.closest('[data-delete]')?.getAttribute('data-delete');
  const list = await storageGet(STORE.PROPOSALS, []);
  if (copyId) {
    const item = list.find((row) => row.id === copyId);
    if (item?.text) {
      await copyText(item.text);
      setBusy(false, 'Proposal copied.');
    }
  }
  if (deleteId) {
    const next = list.filter((row) => row.id !== deleteId);
    await storageSet(STORE.PROPOSALS, next);
    renderProposalList(next);
  }
});

cvListEl?.addEventListener('click', async (event) => {
  const copyId = event.target.closest('[data-copy]')?.getAttribute('data-copy');
  const deleteId = event.target.closest('[data-delete]')?.getAttribute('data-delete');
  const list = await storageGet(STORE.CVS, []);
  if (copyId) {
    const item = list.find((row) => row.id === copyId);
    const text = item?.text || item?.summary || '';
    if (text) {
      await copyText(text);
      setBusy(false, 'CV copied.');
    }
  }
  if (deleteId) {
    const next = list.filter((row) => row.id !== deleteId);
    await storageSet(STORE.CVS, next);
    renderCvList(next);
  }
});

document.getElementById('saveProfile')?.addEventListener('click', async () => {
  const btn = document.getElementById('saveProfile');
  const selectedLang = document.getElementById('outputLanguage')?.value || 'auto';
  if (btn) btn.disabled = true;
  if (profileStatus) {
    profileStatus.classList.remove('err');
    profileStatus.textContent = 'Saving…';
  }
  try {
    const email = String(document.getElementById('accountEmail')?.value || '').trim().toLowerCase();
    const allow = typeof ADMIN_EMAILS !== 'undefined' ? ADMIN_EMAILS : ['kadiryagiz4411@gmail.com'];
    const admin = allow.includes(email);
    await persistSettings({
      skills: document.getElementById('skills')?.value || '',
      hourlyRate: document.getElementById('hourlyRate')?.value || '',
      fixedRate: document.getElementById('fixedRate')?.value || '',
      experience: document.getElementById('experience')?.value || 'mid',
      accountEmail: email,
      outputLanguage: selectedLang === 'auto' ? 'en' : selectedLang,
      languageChoice: selectedLang === 'auto' ? 'auto' : 'explicit',
      isAdmin: admin || settings.isAdmin,
      b2bAccess: admin || settings.b2bAccess,
      role: admin ? 'admin' : settings.role,
    });
    const langLabel = selectedLang === 'auto' ? 'auto-detect' : selectedLang.toUpperCase();
    if (profileStatus) profileStatus.textContent = `Saved (${langLabel}).`;
  } catch (err) {
    console.error('[sovereign] save profile', err);
    if (profileStatus) {
      profileStatus.textContent = 'Could not save. Try again.';
      profileStatus.classList.add('err');
    }
  } finally {
    if (btn) btn.disabled = false;
  }
});

document.getElementById('themeOled')?.addEventListener('click', () => {
  void persistSettings({ theme: 'oled' });
});
document.getElementById('themeObsidian')?.addEventListener('click', () => {
  void persistSettings({ theme: 'obsidian' });
});
document.getElementById('planPro')?.addEventListener('click', () => {
  void persistSettings({ membership: 'pro' });
});
document.getElementById('planLtd')?.addEventListener('click', () => {
  void persistSettings({ membership: 'appsumo' });
});
document.getElementById('pingApi')?.addEventListener('click', () => {
  void pingApi();
});

function setCvBusy(on, message) {
  generatingCv = on;
  const generateCvBtn = document.getElementById('generateCv');
  const copyCvBtn = document.getElementById('copyCv');
  const downloadCvBtn = document.getElementById('downloadCv');
  const cvSpinner = document.getElementById('cvSpinner');
  const cvStatus = document.getElementById('cvStatus');
  if (generateCvBtn) generateCvBtn.disabled = on;
  if (copyCvBtn) copyCvBtn.disabled = on || !lastCv;
  if (downloadCvBtn) downloadCvBtn.disabled = on || !lastCv;
  cvSpinner?.classList.toggle('on', on);
  if (cvStatus) cvStatus.textContent = message;
}

function profileNotes() {
  const skills = skillListFromSettings();
  return [
    skills.length ? `Skills: ${skills.join(', ')}` : '',
    settings.experience ? `Experience: ${settings.experience}` : '',
    settings.hourlyRate ? `Hourly rate: $${settings.hourlyRate}` : '',
    settings.fixedRate ? `Target project rate: $${settings.fixedRate}` : '',
    settings.accountEmail ? `Email: ${settings.accountEmail}` : '',
  ].filter(Boolean).join('\n');
}

function pdfEscape(value) {
  return String(value || '')
    .replace(/\\/g, '\\\\')
    .replace(/\(/g, '\\(')
    .replace(/\)/g, '\\)');
}

function toWinAnsi(value) {
  const map = {
    ş: 's', Ş: 'S', ı: 'i', İ: 'I', ğ: 'g', Ğ: 'G', ü: 'u', Ü: 'U', ö: 'o', Ö: 'O', ç: 'c', Ç: 'C',
    '—': '-', '–': '-', '’': "'", '“': '"', '”': '"',
  };
  return String(value || '').replace(/[^\x20-\x7E\n]/g, (ch) => map[ch] || ' ');
}

function wrapPdfLines(text, width) {
  const out = [];
  for (const raw of String(text || '').split('\n')) {
    const line = raw.trimEnd();
    if (!line) {
      out.push('');
      continue;
    }
    let rest = line;
    while (rest.length > width) {
      let cut = rest.lastIndexOf(' ', width);
      if (cut < 20) cut = width;
      out.push(rest.slice(0, cut));
      rest = rest.slice(cut).trim();
    }
    out.push(rest);
  }
  return out.slice(0, 80);
}

function downloadTextPdf(filename, title, body) {
  const lines = wrapPdfLines(toWinAnsi(`${title}\n\n${body}`), 86);
  const startY = 800;
  const mark = [
    'q',
    '0.82 0.62 0.12 rg',
    'BT',
    '/F2 54 Tf',
    '1 0 0 1 168 400 Tm',
    '0.6 0.35 Td',
    '(SOVEREIGN) Tj',
    'ET',
    'Q',
  ].join('\n');
  const commands = ['BT', '/F1 11 Tf', '14 TL', `72 ${startY} Td`];
  lines.forEach((line, index) => {
    if (index) commands.push('T*');
    commands.push(`(${pdfEscape(line)}) Tj`);
  });
  commands.push('ET');
  const stream = `${mark}\n${commands.join('\n')}`;
  const objects = [
    '1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj',
    '2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj',
    '3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> >> endobj',
    `4 0 obj << /Length ${stream.length} >> stream\n${stream}\nendstream endobj`,
    '5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Times-Roman >> endobj',
    '6 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >> endobj',
  ];
  let offset = 9;
  const offsets = [0];
  let pdf = '%PDF-1.4\n';
  for (const obj of objects) {
    offsets.push(offset);
    pdf += `${obj}\n`;
    offset += obj.length + 1;
  }
  const xrefStart = offset;
  pdf += `xref\n0 7\n0000000000 65535 f \n`;
  for (let i = 1; i <= 6; i += 1) {
    pdf += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer << /Size 7 /Root 1 0 R >>\nstartxref\n${xrefStart}\n%%EOF`;
  const blob = new Blob([pdf], { type: 'application/pdf' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1500);
}

async function saveLeadRecord(record) {
  const list = await storageGet(STORE.LEADS, []);
  const next = [record, ...(Array.isArray(list) ? list : [])].slice(0, 40);
  await storageSet(STORE.LEADS, next);
  renderTeamLeads(next);
}

function renderTeamLeads(list) {
  const el = document.getElementById('teamLeadList');
  if (!el) return;
  if (!list?.length) {
    el.innerHTML = '<div class="empty">No leads captured yet. Extract a company page or job brief.</div>';
    return;
  }
  el.innerHTML = list.map((item) => `
    <article class="list-item">
      <h3>${escapeHtml(item.title || 'Lead')}</h3>
      <div class="when">${escapeHtml(formatWhen(item.at))}</div>
      <p>${escapeHtml(item.text || '')}</p>
    </article>
  `).join('');
}

let resolvingAccess = false;
async function resolveWorkspaceAccess() {
  if (resolvingAccess) return;
  resolvingAccess = true;
  try {
    const sessionBag = await storageGet(STORE.SESSION, null);
    const accessToken = sessionBag?.accessToken || '';
    const viaWorker = await withTimeout(
      chrome.runtime.sendMessage({
        type: 'FETCH_ME',
        accessToken,
      }).catch(() => null),
      4000,
      null,
    );
    const data = viaWorker?.success ? viaWorker.data : null;
    if (!data?.success && !data?.signedIn && !accessToken) {
      applyWorkspaceUi();
      return;
    }
    const nextTier = Number(data?.appsumo_tier ?? settings.appsumoTier ?? 0);
    const nextWorkspace = data?.workspace || settings.workspace || 'b2c';
    const email = String(data?.email || settings.accountEmail || '').trim().toLowerCase();
    const allow = typeof ADMIN_EMAILS !== 'undefined' ? ADMIN_EMAILS : ['kadiryagiz4411@gmail.com'];
    const admin = Boolean(data?.is_admin || data?.isAdmin)
      || allow.includes(email)
      || ['admin', 'superadmin'].includes(String(data?.role || settings.role || '').toLowerCase());
    const planBlob = `${data?.planType || ''} ${data?.plan_type || ''}`.toLowerCase();
    const enterprise = planBlob.includes('enterprise')
      || planBlob.includes('agency')
      || planBlob.includes('b2b');
    const granted = admin
      || enterprise
      || data?.b2bAccessState === 'granted'
      || Boolean(data?.b2b_access || data?.hasB2BAccess);
    const paidPlan = /standard|starter|pro|elite|unlimited|enterprise|agency/.test(planBlob)
      && nextTier !== 1 && nextTier !== 2;
    const dual = admin || granted || paidPlan || nextWorkspace === 'dual' || nextTier >= 3;
    const previousStatus = String(settings.subscriptionStatus || '').toLowerCase();
    await persistSettings({
      accountEmail: data?.email || settings.accountEmail,
      role: admin ? 'admin' : (data?.role || settings.role),
      isAdmin: admin,
      b2bAccess: granted || paidPlan || admin,
      planType: data?.planType || settings.planType || '',
      referralCode: String(data?.referralCode || settings.referralCode || '').trim().toLowerCase(),
      isAppsumoUser: Boolean(data?.is_appsumo_user || data?.isAppsumoUser),
      appsumoTier: nextTier,
      remainingCredits: Number(data?.remainingCredits ?? settings.remainingCredits ?? 0),
      singlePassCredits: Number(data?.singlePassCredits ?? settings.singlePassCredits ?? 0),
      monthlyCreditLimit: Number(data?.monthlyCreditLimit ?? data?.monthlyCredits ?? settings.monthlyCreditLimit ?? 0),
      subscriptionStatus: data?.subscriptionStatus || settings.subscriptionStatus,
      canGenerate: data?.canGenerate !== false,
      workspace: nextWorkspace,
      skills: (Array.isArray(data?.profileSkills) && data.profileSkills.length)
        ? data.profileSkills.join(', ')
        : settings.skills,
      hourlyRate: data?.hourlyRate ? String(data.hourlyRate) : settings.hourlyRate,
      profession: data?.profession || settings.profession,
      pastWins: data?.experienceSummary || settings.pastWins,
      portfolio: data?.portfolio || settings.portfolio,
    });
    applyCreditBadge();
    hidePaywall();
    if (data?.is_appsumo_user && Number(data?.remainingCredits ?? 0) <= 0) {
      showCreditResetBanner();
    } else if (data?.saasExpired && !admin) {
      showPaywall('renew');
    }
    const nextStatus = String(settings.subscriptionStatus || '').toLowerCase();
    const wasPaid = ['active', 'trialing', 'paid', 'lifetime'].includes(previousStatus);
    const nowPaid = ['active', 'trialing', 'paid', 'lifetime'].includes(nextStatus);
    if (previousStatus && previousStatus !== 'unknown' && !wasPaid && nowPaid) {
      void showRatePrompt();
    }
  } catch {
    applyWorkspaceUi();
  } finally {
    resolvingAccess = false;
  }
}

async function saveCvRecord(record) {
  const list = await storageGet(STORE.CVS, []);
  const next = [record, ...(Array.isArray(list) ? list : [])].slice(0, 40);
  await storageSet(STORE.CVS, next);
  renderCvList(next);
  void renderSettingsHistory();
}

async function generateTailoredCv() {
  if (generatingCv) return;
  if (!assertGenerationAllowed()) return;
  // Non-blocking: effectiveSkillList() provides fallback skills if user hasn't
  // completed onboarding yet, so the CV generator always produces a result.
  if (skillListFromSettings().length < 2) {
    setCvBusy(false, 'Tip: Add your skills in Settings for a fully personalized CV. Generating with defaults now…');
  }
  const cvJobMeta = document.getElementById('cvJobMeta');

  // Auto-scan the active tab first to get the freshest job context.
  setCvBusy(true, 'Reading the open job…');
  try {
    const pageData = await getActiveTabDOM();
    lastJob = {
      title: pageData.jobTitle || pageData.pageTitle || lastJob.title,
      url: pageData.pageUrl || lastJob.url,
      description: pageData.jobDescription || pageData.pageText || lastJob.description,
      skills: pageData.requiredSkills || lastJob.skills,
      budget: pageData.budget || lastJob.budget,
      clientHistory: pageData.clientHistory || lastJob.clientHistory,
    };
    if (cvJobMeta) {
      cvJobMeta.textContent = lastJob.title
        ? `Tailoring for: ${lastJob.title}`
        : 'No job detected on active tab.';
    }
    if (String(lastJob.description || '').trim().length < 20) {
      // Last resort: ask user to navigate to a job posting.
      throw new Error('No job description found. Open a job posting in the active tab, then try again.');
    }
    setCvBusy(true, 'Writing a tailored CV…');
    const viaWorker = await chrome.runtime.sendMessage({
      type: 'GENERATE_CV',
      payload: {
        mode: 'generate-from-text',
        targetRole: lastJob.title,
        jobDescription: lastJob.description,
        existingCvText: profileNotes(),
        skills: effectiveSkillList(),
        experience: settings.experience,
        hourlyRate: Number(settings.hourlyRate) || undefined,
        ...languagePayload(),
      },
    }).catch(() => null);
    if (viaWorker?.error) throw new Error(viaWorker.error);
    const data = viaWorker?.success ? viaWorker.data : null;
    const cvText = String(data?.cv || data?.proposal || '').replace(/^\s*[-*_]{3,}\s*$/gm, '').trim();
    if (!cvText) throw new Error('Service temporarily busy. Please try again in a few moments.');
    lastCv = cvText;
    document.getElementById('cvCard')?.classList.add('on');
    renderCvPreview(cvText);
    const scored = await postParseDom(pageData, { scoreOnly: true }).catch(() => data || {});
    const merged = await enrichWithSmartMatch(pageData, scored);
    updateMatchUi(merged, lastJob.title);
    await saveCvRecord({
      id: `${Date.now()}`,
      title: lastJob.title || 'Tailored CV',
      url: lastJob.url,
      text: cvText,
      score: Number(merged?.match_score ?? merged?.matchScore ?? lastScore ?? 0),
      at: Date.now(),
    });
    setCvBusy(false, 'CV ready. Copy or download. Sovereign never auto-submits.');
    void noteAiSuccess();
    void recordGuestUse(data?.guestToken);
  } catch (err) {
    const msg = String(err?.message || err);
    if (/guest_limit/i.test(msg)) {
      showGuestGate();
      setCvBusy(false, 'Sign in to keep generating.');
      return;
    }
    setCvBusy(false, publicError(msg));
  }
}

document.getElementById('extractLead')?.addEventListener('click', () => {
  void analyzeActivePage();
});
document.getElementById('dispatchProposal')?.addEventListener('click', () => {
  void analyzeActivePage();
});
document.getElementById('copyLead')?.addEventListener('click', async () => {
  const text = lastOutreach || lastProposal;
  if (!text) return;
  await copyText(text);
  const leadStatus = document.getElementById('leadStatus');
  if (leadStatus) leadStatus.textContent = 'Outreach copied.';
});
document.getElementById('copyDispatch')?.addEventListener('click', async () => {
  if (!lastProposal) return;
  await copyText(lastProposal);
  const dispatchStatus = document.getElementById('dispatchStatus');
  if (dispatchStatus) dispatchStatus.textContent = 'Copied for the team. Sovereign never auto-submits.';
});
document.getElementById('autofillDispatch')?.addEventListener('click', async () => {
  if (!lastProposal) return;
  const dispatchStatus = document.getElementById('dispatchStatus');
  try {
    const result = await chrome.runtime.sendMessage(injectProposalPayload());
    if (dispatchStatus) {
      dispatchStatus.textContent = result?.success
        ? 'Inserted. Review it, then submit yourself.'
        : 'Open the editor on this page, then tap Auto-Fill again.';
    }
  } catch (err) {
    if (dispatchStatus) dispatchStatus.textContent = publicError(err.message || String(err));
  }
});

document.getElementById('paywallDismiss')?.addEventListener('click', () => {
  hidePaywall();
});
document.getElementById('guestGateDismiss')?.addEventListener('click', () => {
  hideGuestGate();
});

document.getElementById('generateCv')?.addEventListener('click', () => {
  void generateTailoredCv();
});
document.getElementById('copyCv')?.addEventListener('click', async () => {
  if (!lastCv) return;
  await copyText(lastCv);
  setCvBusy(false, 'CV copied.');
});
document.getElementById('downloadCv')?.addEventListener('click', () => {
  if (!lastCv) return;
  const slug = String(lastJob.title || 'sovereign-cv').replace(/[^\w]+/g, '-').replace(/^-|-$/g, '').slice(0, 48);
  downloadTextPdf(`${slug || 'sovereign-cv'}.pdf`, lastJob.title || 'Curriculum Vitae', lastCv);
  setCvBusy(false, 'PDF downloaded.');
});

const B2B_NOTES = 'sovereign.b2b-notes.v1';

async function renderSettingsHistory() {
  const host = document.getElementById('settingsHistory');
  if (!host) return;
  const proposals = await storageGet(STORE.PROPOSALS, []);
  const cvs = await storageGet(STORE.CVS, []);
  const rows = [
    ...(Array.isArray(proposals) ? proposals : []).map((item) => ({ ...item, kind: 'Proposal' })),
    ...(Array.isArray(cvs) ? cvs : []).map((item) => ({ ...item, kind: 'CV' })),
  ].sort((a, b) => Number(b.at || 0) - Number(a.at || 0));
  if (!rows.length) {
    host.innerHTML = '<div class="empty">No history yet.</div>';
    return;
  }
  host.innerHTML = rows.map((item) => `
    <article class="list-item">
      <h3>${escapeHtml(item.kind)} · ${escapeHtml(cleanCardTitle(item.title, 'Untitled'))}</h3>
      <div class="when">${escapeHtml(formatWhen(item.at))}</div>
      <p>${escapeHtml(item.text || item.summary || '')}</p>
      <button class="ghost" type="button" data-history-copy="1" data-history-text="${escapeHtml(item.text || item.summary || '')}">Copy</button>
    </article>
  `).join('');
}

function setB2bDrawer(open) {
  document.getElementById('b2bDrawer')?.classList.toggle('open', open);
  document.getElementById('b2bBackdrop')?.classList.toggle('open', open);
  document.getElementById('b2bDrawer')?.setAttribute('aria-hidden', open ? 'false' : 'true');
  if (open) {
    const client = document.getElementById('b2bClient');
    if (client && !client.value && lastTitle) client.value = lastTitle;
    void renderB2bNotes();
  }
}

async function renderB2bNotes() {
  const host = document.getElementById('b2bNoteList');
  if (!host) return;
  const notes = await storageGet(B2B_NOTES, []);
  const list = Array.isArray(notes) ? notes : [];
  if (!list.length) {
    host.innerHTML = '<div class="empty">No client notes yet.</div>';
    return;
  }
  host.innerHTML = list.map((item) => `
    <article class="list-item">
      <h3>${escapeHtml(item.client || 'Client')}</h3>
      <p>${escapeHtml(item.pitch || '')}</p>
      <button class="ghost" type="button" data-note-copy="1" data-note-text="${escapeHtml(item.pitch || '')}">Copy</button>
    </article>
  `).join('');
}

document.getElementById('openB2bPanel')?.addEventListener('click', () => setB2bDrawer(true));
document.getElementById('closeB2bPanel')?.addEventListener('click', () => setB2bDrawer(false));
document.getElementById('b2bBackdrop')?.addEventListener('click', () => setB2bDrawer(false));
document.getElementById('saveB2bNote')?.addEventListener('click', async () => {
  const client = document.getElementById('b2bClient')?.value?.trim() || 'Client';
  const pitch = document.getElementById('b2bPitch')?.value?.trim() || '';
  const notes = await storageGet(B2B_NOTES, []);
  const next = [{ id: crypto.randomUUID(), client, pitch, at: Date.now() }, ...(Array.isArray(notes) ? notes : [])].slice(0, 30);
  await storageSet(B2B_NOTES, next);
  const status = document.getElementById('b2bDrawerStatus');
  if (status) status.textContent = 'Saved on this device.';
  void renderB2bNotes();
});
document.getElementById('copyB2bPitch')?.addEventListener('click', async () => {
  const pitch = document.getElementById('b2bPitch')?.value || '';
  if (!pitch) return;
  await copyText(pitch);
  const status = document.getElementById('b2bDrawerStatus');
  if (status) status.textContent = 'Pitch copied.';
});
document.getElementById('settingsHistory')?.addEventListener('click', async (event) => {
  const text = event.target.closest('[data-history-text]')?.getAttribute('data-history-text') || '';
  if (!text) return;
  await copyText(text);
  if (profileStatus) profileStatus.textContent = 'Copied from history.';
});
document.getElementById('b2bNoteList')?.addEventListener('click', async (event) => {
  const text = event.target.closest('[data-note-text]')?.getAttribute('data-note-text') || '';
  if (!text) return;
  await copyText(text);
});

function activeB2bBlock() {
  return b2bBlock === 'proposal' ? b2bBlocks.proposal : b2bBlocks.candidate;
}

function renderContextDrawer() {
  const block = activeB2bBlock();
  const label = document.getElementById('contextModeLabel');
  const name = document.getElementById('contextFileName');
  const status = document.getElementById('contextStatus');
  if (label) {
    label.textContent = b2bBlock === 'proposal'
      ? 'Feeds Proposal analysis only'
      : 'Feeds Candidate analysis only';
  }
  if (name) name.textContent = block.fileName ? `Loaded: ${block.fileName}` : 'No file in this block.';
  if (status) {
    if (block.error) status.textContent = block.error;
    else if (block.phase === 'analyzing') status.textContent = 'Analyzing…';
    else if (block.phase === 'loaded' || block.phase === 'ready') status.textContent = 'File loaded.';
    else status.textContent = '';
  }
}

function setContextDrawer(open) {
  const toggle = document.getElementById('contextDrawerToggle');
  document.getElementById('contextDrawer')?.classList.toggle('open', open);
  document.getElementById('contextDrawer')?.setAttribute('aria-hidden', open ? 'false' : 'true');
  toggle?.classList.toggle('on', open);
  toggle?.setAttribute('aria-expanded', open ? 'true' : 'false');
  renderContextDrawer();
}

function pullPdfStrings(text) {
  const parts = [];
  const literal = /\((?:\\\)|\\.|[^\\)]){2,}\)/g;
  let match;
  while ((match = literal.exec(text))) {
    const raw = match[0].slice(1, -1)
      .replace(/\\n/g, '\n')
      .replace(/\\r/g, '')
      .replace(/\\t/g, ' ')
      .replace(/\\\(/g, '(')
      .replace(/\\\)/g, ')')
      .replace(/\\\\/g, '\\');
    if (/[A-Za-zÀ-ÿĞğÜüŞşİıÖöÇç]{3}/.test(raw)) parts.push(raw);
  }
  return parts.join(' ');
}

async function inflatePdfStream(bytes) {
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate'));
  const buf = await new Response(stream).arrayBuffer();
  return new TextDecoder('utf-8', { fatal: false }).decode(buf);
}

function findAscii(bytes, needle, from) {
  const start = from || 0;
  outer: for (let i = start; i <= bytes.length - needle.length; i += 1) {
    for (let j = 0; j < needle.length; j += 1) {
      if (bytes[i + j] !== needle[j]) continue outer;
    }
    return i;
  }
  return -1;
}

async function extractPdfText(buffer) {
  const bytes = new Uint8Array(buffer);
  const streamMark = [115, 116, 114, 101, 97, 109];
  const endMark = [101, 110, 100, 115, 116, 114, 101, 97, 109];
  const chunks = [];
  let cursor = 0;
  while (cursor < bytes.length) {
    const at = findAscii(bytes, streamMark, cursor);
    if (at < 0) break;
    let dataStart = at + streamMark.length;
    if (bytes[dataStart] === 13 && bytes[dataStart + 1] === 10) dataStart += 2;
    else if (bytes[dataStart] === 10 || bytes[dataStart] === 13) dataStart += 1;
    const end = findAscii(bytes, endMark, dataStart);
    if (end < 0) break;
    const slice = bytes.slice(dataStart, end);
    const head = new TextDecoder('latin1').decode(bytes.slice(Math.max(0, at - 180), at));
    let text = '';
    if (/FlateDecode/.test(head)) {
      try { text = await inflatePdfStream(slice); } catch { text = ''; }
    } else {
      text = new TextDecoder('latin1').decode(slice);
    }
    const pulled = pullPdfStrings(text);
    if (pulled) chunks.push(pulled);
    cursor = end + endMark.length;
  }
  const joined = chunks.join('\n').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  if (joined.length < 40) {
    throw new Error('Could not read text from this PDF. Export it as TXT or use a text-based PDF.');
  }
  return joined.slice(0, 12000);
}

async function inflateRaw(bytes) {
  if (typeof DecompressionStream !== 'function') {
    throw new Error('This browser cannot unpack DOCX. Save the file as TXT or PDF.');
  }
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  const buf = await new Response(stream).arrayBuffer();
  return new TextDecoder('utf-8').decode(buf);
}

async function extractDocxText(buffer) {
  const bytes = new Uint8Array(buffer);
  let xml = '';
  for (let offset = 0; offset + 30 < bytes.length;) {
    if (bytes[offset] !== 0x50 || bytes[offset + 1] !== 0x4b || bytes[offset + 2] !== 0x03 || bytes[offset + 3] !== 0x04) {
      offset += 1;
      continue;
    }
    const method = bytes[offset + 8] | (bytes[offset + 9] << 8);
    const compSize = bytes[offset + 18] | (bytes[offset + 19] << 8) | (bytes[offset + 20] << 16) | (bytes[offset + 21] << 24);
    const nameLen = bytes[offset + 26] | (bytes[offset + 27] << 8);
    const extraLen = bytes[offset + 28] | (bytes[offset + 29] << 8);
    const nameStart = offset + 30;
    const name = new TextDecoder('utf-8').decode(bytes.slice(nameStart, nameStart + nameLen));
    const dataStart = nameStart + nameLen + extraLen;
    if (!compSize || dataStart + compSize > bytes.length) {
      offset = Math.max(dataStart, offset + 4);
      continue;
    }
    if (name === 'word/document.xml') {
      const slice = bytes.slice(dataStart, dataStart + compSize);
      xml = method === 0 ? new TextDecoder('utf-8').decode(slice) : await inflateRaw(slice);
      break;
    }
    offset = dataStart + compSize;
  }
  if (!xml) throw new Error('Could not read text from this DOCX. Export it as TXT or PDF.');
  const text = xml
    .replace(/<w:p[^>]*>/g, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  if (text.length < 20) throw new Error('That DOCX file has no readable text.');
  return text.slice(0, 12000);
}

function sanitizeUploadText(text) {
  return String(text || '')
    .replace(/\u0000/g, '')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
    .slice(0, 12000);
}

async function persistDefaultCv(text, name) {
  const clean = String(text || '').trim();
  if (clean.length < 20) return;
  await storageSet(STORE.DEFAULT_CV, {
    text: clean.slice(0, 12000),
    name: String(name || 'Default profile'),
    at: Date.now(),
  });
}

async function loadDefaultCv() {
  const saved = await storageGet(STORE.DEFAULT_CV, null);
  const text = String(saved?.text || '').trim();
  const field = document.getElementById('instantCv');
  const toggle = document.getElementById('saveDefaultCv');
  if (toggle) toggle.checked = text.length >= 20;
  if (field && text.length >= 20 && String(field.value || '').trim().length < 20) {
    field.value = text;
  }
}

async function autoFillFromActiveTab() {
  try {
    const focused = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    let tab = focused?.[0];
    if (!tab?.id) {
      const current = await chrome.tabs.query({ active: true, currentWindow: true });
      tab = current?.[0];
    }
    const url = String(tab?.url || '');
    if (isRestrictedTabUrl(url)) {
      setScanButton('idle');
      setBusy(false, 'Open a job post on LinkedIn, Upwork, or any webpage to scan.');
      return;
    }
    if (!tab?.id) return;
    const scraped = await chrome.runtime.sendMessage({ type: 'SCRAPE_ACTIVE_TAB' }).catch((err) => {
      console.error('[Sovereign] auto-fill scrape', err?.message || err);
      return null;
    });
    if (scraped?.error) {
      console.error('[Sovereign] auto-fill scrape', scraped.error);
      if (/Open a job post on LinkedIn/i.test(String(scraped.error))) {
        setBusy(false, scraped.error);
      }
      return;
    }
    const data = scraped?.success ? normalizePageData(scraped.data) : null;
    const text = String(data?.jobDescription || data?.pageText || '').trim();
    if (!data || data.discarded || text.length < 40) {
      if (isJobBoardUrl(url)) setBusy(false, 'Open a job post on LinkedIn, Upwork, or any webpage to scan.');
      return;
    }
    applyIsolatedJob(data);
    setTargetBadge('live', lastJob.title, lastJob.kind, lastJob.contentType);
    showJobAutoFillHint(true);
    const status = document.getElementById('instantStatus');
    if (status) status.textContent = 'Job loaded from this tab. Click Handle with Sovereign.';
  } catch (err) {
    console.error('[Sovereign] auto-fill', err?.message || err);
  }
}

async function extractDroppedFile(file) {
  const name = String(file?.name || 'file');
  const ext = name.split('.').pop()?.toLowerCase() || '';
  const type = String(file?.type || '');
  try {
    if (ext === 'txt' || type.startsWith('text/plain')) {
      const text = sanitizeUploadText(await file.text());
      if (text.length < 20) throw new Error('That text file is too short to analyze.');
      return text;
    }
    if (ext === 'html' || ext === 'htm' || type === 'text/html') {
      const raw = await file.text();
      const doc = new DOMParser().parseFromString(raw, 'text/html');
      doc.querySelectorAll('script, style, noscript').forEach((node) => node.remove());
      const text = sanitizeUploadText(String(doc.body?.innerText || '').replace(/[ \t]{2,}/g, ' '));
      if (text.length < 20) throw new Error('That HTML file has no readable text.');
      return text;
    }
    if (ext === 'docx' || type.includes('wordprocessingml')) {
      return extractDocxText(await file.arrayBuffer());
    }
    if (ext === 'pdf' || type === 'application/pdf') {
      return sanitizeUploadText(await extractPdfText(await file.arrayBuffer()));
    }
  } catch (err) {
    if (err instanceof Error && err.message) throw err;
    throw new Error('Could not read that file. Paste the text instead.');
  }
  throw new Error('Use a PDF, DOCX, TXT, or HTML file.');
}

function blockSpinner(mode) {
  return document.getElementById(mode === 'proposal' ? 'proposalBlockSpinner' : 'candidateBlockSpinner');
}

function fileAnalysisError(err) {
  const raw = String(err?.message || err || '').replace(/\s+/g, ' ').trim();
  console.error('[sovereign] file analysis failed', raw || err);
  if (/too long to read|too short to analyze|no readable text|Could not read text|Use a PDF|DOCX|unpack/i.test(raw)) return raw;
  if (/took too long/i.test(raw)) return 'Analysis took too long. Try the file again.';
  if (/OPENAI|vercel|parse-dom|api[_ ]?key|stack|Check Vercel/i.test(raw)) {
    return 'Analysis could not finish. Try the file again.';
  }
  if (raw && raw.length < 140 && !/https?:|at\s+\w+\s+\(/i.test(raw)) return raw;
  return 'Analysis could not finish. Try the file again.';
}

function detectUploadKind(fileName, text) {
  const name = String(fileName || '').toLowerCase();
  const sample = `${name}\n${String(text || '').slice(0, 4000)}`;
  const resumeName = /\b(cv|resume|résumé|curriculum|vitae)\b/i.test(name);
  const briefName = /\b(job|brief|proposal|cover|rfp|sow|posting)\b/i.test(name);
  const resumeHits = (sample.match(/curriculum vitae|\bcv\b|work experience|professional experience|\beducation\b|\bskills\b|certifications|years of experience/gi) || []).length;
  const briefHits = (sample.match(/job description|responsibilities|qualifications|requirements|we are (?:looking|seeking|hiring)|cover letter|project scope|\bproposal\b|deliverables?|milestone/gi) || []).length;
  if (resumeName && !briefName) return 'candidate';
  if (briefName && !resumeName) return 'proposal';
  if (resumeHits > briefHits) return 'candidate';
  return 'proposal';
}

function setBlockStatus(mode, message, isError) {
  const status = document.getElementById(mode === 'proposal' ? 'proposalBlockStatus' : 'candidateBlockStatus');
  if (!status) return;
  status.textContent = message;
  status.classList.toggle('err', Boolean(isError));
}

function revealAnalysisTab(mode) {
  const id = mode === 'proposal' ? 'b2b-proposal' : 'candidate';
  if (effectiveMode() === 'b2b') {
    switchTab(id);
    return;
  }
  document.querySelectorAll('.tab-view').forEach((view) => {
    view.classList.toggle('on', view.id === `tab-${id}`);
  });
}

async function runB2bBlock(mode) {
  const key = mode === 'proposal' ? 'proposal' : 'candidate';
  b2bBlock = key;
  const seq = (b2bRunSeq[key] += 1);
  const block = key === 'proposal' ? b2bBlocks.proposal : b2bBlocks.candidate;
  const spinner = blockSpinner(key);
  const current = () => b2bRunSeq[key] === seq;
  block.error = '';
  block.phase = 'analyzing';
  setBlockStatus(key, key === 'proposal' ? 'Tuning the proposal…' : 'Scoring the candidate…', false);
  spinner?.classList.add('on');
  renderContextDrawer();
  try {
    let pageData = null;
    try {
      pageData = await withTimeout(getActiveTabDOM(), 8000, 'The open page took too long to read.');
    } catch (err) {
      console.warn('[sovereign] open page skipped', err?.message || err);
      pageData = null;
    }
    if (!current()) return;
    const source = String(block.text || '').trim();
    const pageText = String(pageData?.pageText || pageData?.jobDescription || '').trim();
    const pageOk = key === 'candidate' && pageText.length >= 40;
    if (!pageOk && source.length < 20) {
      block.phase = 'error';
      block.error = 'Drop a PDF, DOCX, TXT, or HTML resume or job brief.';
      setBlockStatus(key, block.error, true);
      return;
    }
    const base = pageOk ? pageData : {
      pageText: source,
      pageTitle: block.fileName || 'Uploaded document',
      pageUrl: '',
      jobTitle: block.fileName || 'Uploaded document',
      jobDescription: source,
      requiredSkills: [],
      budget: '',
      clientHistory: '',
    };
    const data = await withTimeout(postParseDom(base, {
      analysisMode: key,
      uploadedText: source,
    }), 35000, 'Analysis took too long. Try the file again.');
    if (!current()) return;
    block.result = data;
    block.phase = 'ready';
    renderB2bBlock(key);
    setBlockStatus(key, key === 'proposal' ? 'Proposal draft ready.' : 'Resume scored.', false);
    void noteAiSuccess();
  } catch (err) {
    if (!current()) return;
    block.phase = 'error';
    block.result = null;
    block.error = fileAnalysisError(err);
    renderB2bBlock(key);
    setBlockStatus(key, block.error, true);
  } finally {
    if (current()) {
      spinner?.classList.remove('on');
      if (block.phase === 'analyzing') block.phase = block.error ? 'error' : 'ready';
      renderContextDrawer();
    }
  }
}

function listLines(items) {
  if (!Array.isArray(items) || !items.length) return 'None found.';
  return items.map((item) => `• ${typeof item === 'string' ? item : (item?.area || item?.detail || '')}`).filter((line) => line !== '• ').join('\n');
}

function renderB2bBlock(mode) {
  const block = mode === 'proposal' ? b2bBlocks.proposal : b2bBlocks.candidate;
  const data = block.result || {};
  if (!block.result) {
    ['proposalHooks', 'proposalLetter', 'candidateScore', 'candidateSummary', 'candidateSkills', 'candidateGaps', 'candidateTips']
      .forEach((id) => {
        const node = document.getElementById(id);
        if (node) node.textContent = '';
      });
    return;
  }
  if (mode === 'proposal') {
    const hooks = document.getElementById('proposalHooks');
    const letter = document.getElementById('proposalLetter');
    if (hooks) hooks.textContent = listLines(data.hooks);
    if (letter) letter.textContent = data.proposalText || data.summary || '';
    return;
  }
  const score = document.getElementById('candidateScore');
  const summary = document.getElementById('candidateSummary');
  const skills = document.getElementById('candidateSkills');
  const gaps = document.getElementById('candidateGaps');
  const tips = document.getElementById('candidateTips');
  if (score) score.textContent = String(data.overallScore ?? data.matchScore ?? '—');
  if (summary) summary.textContent = data.summary || data.whyThisCandidate || '';
  if (skills) skills.textContent = listLines(data.skillMatches || data.pros || data.strengths);
  if (gaps) gaps.textContent = listLines(data.candidateGaps || data.cons || data.gaps);
  if (tips) tips.textContent = listLines(data.recommendations);
}

document.getElementById('contextDrawerToggle')?.addEventListener('click', () => {
  const open = !document.getElementById('contextDrawer')?.classList.contains('open');
  setContextDrawer(open);
});
document.getElementById('contextDrawerClose')?.addEventListener('click', () => setContextDrawer(false));
document.getElementById('contextDrop')?.addEventListener('click', () => {
  document.getElementById('contextFile')?.click();
});
document.getElementById('contextDrop')?.addEventListener('dragover', (event) => {
  event.preventDefault();
  event.currentTarget.classList.add('over');
});
document.getElementById('contextDrop')?.addEventListener('dragleave', (event) => {
  event.currentTarget.classList.remove('over');
});
document.getElementById('contextDrop')?.addEventListener('drop', (event) => {
  event.preventDefault();
  event.currentTarget.classList.remove('over');
  const file = event.dataTransfer?.files?.[0];
  if (file) void acceptContextFile(file);
});
document.getElementById('contextFile')?.addEventListener('change', (event) => {
  const file = event.target.files?.[0];
  event.target.value = '';
  if (file) void acceptContextFile(file);
});
document.getElementById('contextClear')?.addEventListener('click', () => {
  const block = activeB2bBlock();
  b2bRunSeq[b2bBlock] += 1;
  block.fileName = '';
  block.text = '';
  block.error = '';
  block.result = null;
  block.phase = '';
  blockSpinner(b2bBlock)?.classList.remove('on');
  renderB2bBlock(b2bBlock);
  renderContextDrawer();
});

async function acceptContextFile(file) {
  const status = document.getElementById('contextStatus');
  if (status) status.textContent = 'Reading file…';
  let mode = b2bBlock === 'proposal' ? 'proposal' : 'candidate';
  try {
    const text = await withTimeout(
      extractDroppedFile(file),
      12000,
      'That file took too long to read. Try a TXT or HTML export.',
    );
    mode = detectUploadKind(file.name, text);
    const block = b2bBlocks[mode];
    block.text = text;
    block.fileName = file.name;
    block.error = '';
    block.result = null;
    block.phase = 'loaded';
    b2bBlock = mode;
    if (mode === 'candidate') {
      const signature = `${file.name}:${file.size || 0}`;
      if (!cvBatch.some((item) => item.signature === signature)) {
        cvBatch.push({
          id: `cv-${Date.now()}-${cvBatchSeq += 1}`,
          name: String(file.name || 'Untitled CV'),
          signature,
          text,
          result: null,
          error: '',
          phase: 'loaded',
          shortlisted: false,
        });
        renderCvBatchList();
      }
    }
    renderContextDrawer();
    revealAnalysisTab(mode);
    setContextDrawer(false);
    await runB2bBlock(mode);
  } catch (err) {
    const block = b2bBlocks[mode];
    block.phase = 'error';
    block.error = fileAnalysisError(err);
    if (status) status.textContent = block.error;
    blockSpinner(mode)?.classList.remove('on');
    renderContextDrawer();
  }
}

const INSTANT_SKILLS = ['react', 'typescript', 'javascript', 'node', 'python', 'supabase', 'sql', 'aws', 'figma', 'seo', 'wordpress', 'shopify', 'java', 'go', 'rust', 'docker', 'graphql', 'tailwind', 'next.js', 'vue', 'php', 'laravel', 'design', 'marketing', 'sales', 'copywriting'];

const SCORE_STOP = new Set(['the', 'and', 'for', 'with', 'you', 'your', 'this', 'that', 'from', 'are', 'was', 'were', 'have', 'has', 'will', 'our', 'their', 'about', 'into', 'job', 'role', 'work', 'team', 'using', 'use', 'can', 'not', 'but', 'all', 'any', 'who', 'what', 'when', 'where', 'which', 'they', 'them', 'his', 'her', 'she', 'him', 'its', 'per', 'via', 'also', 'than', 'then', 'such', 'each', 'more', 'most', 'very', 'just', 'able', 'need', 'needs']);

function scoreTokens(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/[^a-z0-9+#.\s-]/g, ' ')
    .split(/\s+/)
    .map((word) => word.trim())
    .filter((word) => word.length > 2 && !SCORE_STOP.has(word));
}

function termFrequency(words) {
  const map = new Map();
  words.forEach((word) => map.set(word, (map.get(word) || 0) + 1));
  return map;
}

function scoreOverlap(jobText, cvText) {
  const jobWords = scoreTokens(jobText);
  const cvWords = scoreTokens(cvText);
  const jobTf = termFrequency(jobWords);
  const cvTf = termFrequency(cvWords);
  const hay = String(jobText || '').toLowerCase();
  const cv = String(cvText || '').toLowerCase();
  const asked = INSTANT_SKILLS.filter((skill) => hay.includes(skill));
  const resumeSkills = INSTANT_SKILLS.filter((skill) => cv.includes(skill));
  const profile = skillListFromSettings().map((skill) => skill.toLowerCase());
  const basis = resumeSkills.length ? resumeSkills : profile;
  const skillHits = asked.filter((skill) => basis.some((item) => item.includes(skill) || skill.includes(item)) || cv.includes(skill));
  let weight = 0;
  let possible = 0;
  const matched = [];
  const missing = [];
  jobTf.forEach((count, term) => {
    const idf = 1 + Math.log((jobWords.length + 1) / (count + 1));
    const importance = count * idf;
    possible += importance;
    if (cvTf.has(term) || basis.some((skill) => skill === term || skill.includes(term))) {
      const seen = cvTf.get(term) || 1;
      weight += importance * Math.min(1, seen / count);
      if (matched.length < 6 && term.length > 3) matched.push(term);
    } else if (importance > 1.6 && missing.length < 5 && term.length > 3) {
      missing.push(term);
    }
  });
  skillHits.forEach((skill) => {
    if (!matched.includes(skill)) matched.unshift(skill);
  });
  const textScore = possible > 0 ? weight / possible : 0;
  const skillScore = asked.length ? skillHits.length / asked.length : (basis.length && textScore ? textScore : 0);
  const blended = asked.length ? (textScore * 0.45 + skillScore * 0.55) : textScore;
  const match = (!jobWords.length || !cvWords.length && !basis.length) ? 0 : clampScore(blended * 100);
  const cvBasis = Math.max(asked.length || resumeSkills.length, 1);
  const cvScore = resumeSkills.length
    ? clampScore((skillHits.length / cvBasis) * 100)
    : match;
  const shown = matched.filter((term) => asked.includes(term) || term.length > 4).slice(0, 4);
  const gap = asked.find((skill) => !skillHits.includes(skill)) || '';
  const breakdown = !jobWords.length
    ? 'Paste or upload a job brief to calculate a match.'
    : (!cvWords.length && basis.length < 2)
      ? 'Paste or upload a resume, or save at least two skills in Settings.'
      : shown.length
        ? `Overlap on ${shown.join(', ')}${gap ? `. The brief also asks for ${gap}` : ''}.`
        : 'Little keyword overlap between the resume and this brief.';
  return {
    match,
    cv: cvScore,
    missing: asked.filter((skill) => !skillHits.includes(skill)).slice(0, 3),
    matched: shown,
    breakdown,
  };
}

function instantScores(jobText, cvText) {
  return scoreOverlap(jobText, cvText);
}

function previewProposal(jobText, lang) {
  const line = String(jobText || '').replace(/\s+/g, ' ').trim().slice(0, 140);
  const subject = line || 'the first deliverable';
  const packs = {
    en: `I can start this week. I will ship a concrete first version of ${subject} within two days, then adjust it against your notes.`,
    tr: `Bu hafta başlayabilirim. ${subject} için iki gün içinde somut bir ilk sürüm gönderir, sonra notlarınıza göre düzeltirim.`,
    de: `Ich kann diese Woche starten. Eine erste Fassung von ${subject} liegt in zwei Tagen vor, danach passe ich sie an dein Feedback an.`,
    fr: `Je peux commencer cette semaine. Une première version de ${subject} part sous deux jours, puis je l’ajuste selon vos retours.`,
    es: `Puedo empezar esta semana. Envío una primera versión de ${subject} en dos días y luego la ajusto con tus notas.`,
  };
  return packs[lang] || packs.en;
}

let lastInstant = { match: 0, cv: 0, proposal: '' };

function paintInstant(match, cv, proposal, status, breakdown) {
  const safeMatch = clampScore(match);
  const safeCv = clampScore(cv);
  const matchEl = document.getElementById('instantMatch');
  const cvEl = document.getElementById('instantCvScore');
  const proposalEl = document.getElementById('instantProposal');
  const statusEl = document.getElementById('instantStatus');
  const summary = document.getElementById('shareSummary');
  const breakEl = document.getElementById('instantBreakdown');
  if (matchEl) matchEl.textContent = `${safeMatch}%`;
  if (cvEl) cvEl.textContent = `${safeCv}%`;
  if (proposalEl) proposalEl.textContent = proposal;
  if (statusEl) statusEl.textContent = status;
  if (breakEl) breakEl.textContent = breakdown || '';
  if (summary) summary.textContent = `Match ${safeMatch}% · CV ${safeCv}%`;
  lastInstant = { match: safeMatch, cv: safeCv, proposal };
  paintMonster(safeMatch);
  paintPoach(lastTitle || lastJob.title || 'Instant brief', document.getElementById('instantJob')?.value || lastJob.description || '', lastJob.url || lastJobUrl || '');
  paintArmor(document.getElementById('instantCv')?.value || '', document.getElementById('instantJob')?.value || lastJob.description || '');
}

async function runInstant(source) {
  const statusEl = document.getElementById('instantStatus');
  const job = document.getElementById('instantJob')?.value || '';
  const cv = document.getElementById('instantCv')?.value || '';
  if (job.trim().length < 20 && cv.trim().length < 20) {
    if (statusEl) statusEl.textContent = 'Paste a job or a resume with at least a few sentences.';
    return;
  }
  const scores = instantScores(job || cv, cv || job);
  const lang = detectSourceLanguage(`${job}\n${cv}`) || 'en';
  const preview = previewProposal(job || cv, lang);
  paintInstant(scores.match, scores.cv, preview, 'Scores are ready. Preview draft is on screen.', scores.breakdown);
  if (source === 'demo') return;
  if (!assertGenerationAllowed()) return;
  if (statusEl) statusEl.textContent = 'Scores are ready. Writing your proposal…';
  try {
    const pageData = {
      pageText: job || cv,
      pageTitle: 'Instant brief',
      pageUrl: '',
      jobTitle: 'Instant brief',
      jobDescription: job || cv,
      requiredSkills: scores.missing,
    };
    const data = await withTimeout(
      postParseDom(pageData, { analysisMode: cv.trim().length > job.trim().length ? 'candidate' : 'proposal', uploadedText: cv || job }),
      35000,
      'The proposal took too long. The scores above are still saved on screen.',
    );
    const proposal = String(data?.proposalText || data?.summary || preview).trim();
    paintInstant(scores.match, scores.cv, proposal || preview, 'Proposal ready.', scores.breakdown);
    void noteAiSuccess();
    void recordGuestUse(data?.guestToken);
  } catch (err) {
    console.error('[sovereign] instant analysis', err);
    if (/guest_limit/i.test(String(err?.message || err))) {
      showGuestGate();
      if (statusEl) statusEl.textContent = 'Sign in to keep generating.';
      return;
    }
    if (statusEl) statusEl.textContent = 'Scores stayed on screen. The proposal did not finish. Try again.';
  }
}

function shareCanvas() {
  const canvas = document.createElement('canvas');
  canvas.width = 1080;
  canvas.height = 1080;
  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;
  ctx.fillStyle = '#09090B';
  ctx.fillRect(0, 0, 1080, 1080);
  ctx.strokeStyle = '#d4af37';
  ctx.lineWidth = 8;
  ctx.strokeRect(48, 48, 984, 984);
  ctx.fillStyle = '#f5e6b8';
  ctx.font = '700 42px sans-serif';
  ctx.fillText('Sovereign | Secure Your Gig', 90, 180);
  ctx.fillStyle = '#ffffff';
  ctx.font = '700 120px sans-serif';
  ctx.fillText(`${lastInstant.match || 0}%`, 90, 460);
  ctx.font = '600 36px sans-serif';
  ctx.fillStyle = '#a1a1aa';
  ctx.fillText('MATCH SCORE', 90, 520);
  ctx.fillStyle = '#ffffff';
  ctx.font = '700 92px sans-serif';
  ctx.fillText(`${lastInstant.cv || 0}%`, 90, 700);
  ctx.font = '600 36px sans-serif';
  ctx.fillStyle = '#a1a1aa';
  ctx.fillText('CV SCORE', 90, 760);
  ctx.fillStyle = '#d4af37';
  ctx.font = '600 28px sans-serif';
  ctx.fillText('sovereignapp.pro', 90, 960);
  return canvas;
}

async function copyShareCard() {
  const statusEl = document.getElementById('instantStatus');
  try {
    const canvas = shareCanvas();
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
    if (!blob) throw new Error('card');
    if (navigator.clipboard && window.ClipboardItem) {
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      if (statusEl) statusEl.textContent = 'Share card copied.';
      return;
    }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'sovereign-score.png';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1500);
    if (statusEl) statusEl.textContent = 'Share card downloaded.';
  } catch (err) {
    console.error('[sovereign] share card', err);
    const text = `Match ${lastInstant.match}% · CV ${lastInstant.cv}%\nSovereign | Secure Your Gig`;
    await copyText(text);
    if (statusEl) statusEl.textContent = 'Copied the score text.';
  }
}

async function fillInstantFromFile(file, targetId) {
  const statusEl = document.getElementById('instantStatus');
  if (statusEl) statusEl.textContent = 'Reading the file…';
  try {
    const text = await withTimeout(extractDroppedFile(file), 12000, 'That file took too long to read.');
    const kind = targetId
      ? (targetId === 'instantCv' ? 'candidate' : 'proposal')
      : detectUploadKind(file.name, text);
    const target = document.getElementById(targetId || (kind === 'candidate' ? 'instantCv' : 'instantJob'));
    if (target) target.value = text;
    if (targetId === 'instantCv' || kind === 'candidate') {
      if (statusEl) statusEl.textContent = 'Resume loaded. Click Handle with Sovereign.';
      const save = document.getElementById('saveDefaultCv');
      if (save?.checked) await persistDefaultCv(text, file.name);
    } else if (statusEl) {
      statusEl.textContent = 'Brief loaded. Click Handle with Sovereign.';
    }
  } catch (err) {
    console.error('[sovereign] instant file', err);
    if (statusEl) statusEl.textContent = fileAnalysisError(err);
  }
}

function bindFileDrop(zone, input, targetId) {
  if (!zone) return;
  const openPicker = () => input?.click();
  zone.addEventListener('click', (event) => {
    if (event.target.closest('textarea, input, button, a')) return;
    openPicker();
  });
  zone.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      openPicker();
    }
  });
  zone.addEventListener('dragover', (event) => {
    event.preventDefault();
    zone.classList.add('over');
  });
  zone.addEventListener('dragleave', () => zone.classList.remove('over'));
  zone.addEventListener('drop', (event) => {
    event.preventDefault();
    zone.classList.remove('over');
    const file = event.dataTransfer?.files?.[0];
    if (file) void fillInstantFromFile(file, targetId);
  });
  input?.addEventListener('change', (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (file) void fillInstantFromFile(file, targetId);
  });
}

function bindInstant() {
  bindFileDrop(document.getElementById('jobDrop'), document.getElementById('jobFile'), 'instantJob');
  bindFileDrop(document.getElementById('cvDrop'), document.getElementById('cvFile'), 'instantCv');
  document.getElementById('instantPick')?.addEventListener('click', () => {
    document.getElementById('instantFile')?.click();
  });
  document.getElementById('cvImportBtn')?.addEventListener('click', () => {
    document.getElementById('cvFile')?.click();
  });
  document.getElementById('saveDefaultCv')?.addEventListener('change', async (event) => {
    const on = Boolean(event.target?.checked);
    const text = document.getElementById('instantCv')?.value || '';
    if (on) await persistDefaultCv(text, 'Default profile');
    else await storageSet(STORE.DEFAULT_CV, null);
  });
  document.getElementById('instantCv')?.addEventListener('blur', () => {
    const toggle = document.getElementById('saveDefaultCv');
    if (!toggle?.checked) return;
    void persistDefaultCv(document.getElementById('instantCv')?.value || '', 'Default profile');
  });
  document.getElementById('instantFile')?.addEventListener('change', (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (file) void fillInstantFromFile(file, '');
  });
  ['instantJob', 'instantCv'].forEach((id) => {
    const field = document.getElementById(id);
    field?.addEventListener('dragover', (event) => {
      if (!event.dataTransfer?.types?.includes('Files')) return;
      event.preventDefault();
      field.classList.add('over');
    });
    field?.addEventListener('dragleave', () => field.classList.remove('over'));
    field?.addEventListener('drop', (event) => {
      const file = event.dataTransfer?.files?.[0];
      if (!file) return;
      event.preventDefault();
      field.classList.remove('over');
      void fillInstantFromFile(file, id);
    });
  });
  document.getElementById('instantRun')?.addEventListener('click', () => {
    void runInstant('manual');
  });
  document.getElementById('poachDeploy')?.addEventListener('click', () => {
    const job = document.getElementById('instantJob');
    if (job && lastJob.description && !String(job.value || '').trim()) job.value = lastJob.description;
    switchTab('proposal');
    document.getElementById('analyze')?.click();
  });
  document.getElementById('shareMonster')?.addEventListener('click', () => {
    const safe = clampScore(lastScore || lastInstant.match);
    const text = `Sovereign fit score: ${safe}/100. https://sovereignapp.pro #Sovereign`;
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer');
  });
  document.querySelectorAll('[data-armor]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const mode = btn.getAttribute('data-armor');
      document.querySelectorAll('[data-armor]').forEach((el) => el.classList.toggle('on', el === btn));
      document.getElementById('armorOriginal')?.toggleAttribute('hidden', mode !== 'original');
      document.getElementById('armorArmed')?.toggleAttribute('hidden', mode !== 'armored');
    });
  });
  document.getElementById('headerUpload')?.addEventListener('click', () => {
    try {
      if (effectiveMode() === 'b2b') {
        const onCandidate = document.getElementById('tab-candidate')?.classList.contains('on');
        if (onCandidate) {
          document.getElementById('cvBatchFile')?.click();
          return;
        }
        setContextDrawer(true);
        document.getElementById('contextFile')?.click();
        return;
      }
      switchTab('instant');
      document.getElementById('instantFile')?.click();
    } catch (err) {
      console.error('[sovereign] upload', err);
    }
  });
  document.getElementById('copyShare')?.addEventListener('click', () => { void copyShareCard(); });
  document.getElementById('copyReferral')?.addEventListener('click', async () => {
    const url = referralUrl();
    const statusEl = document.getElementById('instantStatus');
    if (!url) {
      window.open('https://sovereignapp.pro/auth?mode=signup', '_blank', 'noopener');
      if (statusEl) statusEl.textContent = 'Sign in to generate your referral link.';
      return;
    }
    try {
      await copyText(url);
      if (statusEl) statusEl.textContent = 'Referral link copied.';
    } catch (err) {
      console.error('[sovereign] referral copy', err);
      if (statusEl) statusEl.textContent = 'Could not copy the link. Select it in Settings.';
    }
  });
  document.getElementById('rateLater')?.addEventListener('click', () => {
    document.getElementById('rateModal')?.classList.remove('on');
  });
  document.getElementById('rateStars')?.addEventListener('click', async (event) => {
    const star = event.target.closest('[data-star]');
    if (!star) return;
    try {
      await storageSet(STORE.RATED, true);
      document.getElementById('rateModal')?.classList.remove('on');
      window.open(reviewUrl(), '_blank', 'noopener');
    } catch (err) {
      console.error('[sovereign] rate', err);
    }
  });
  document.getElementById('rateStore')?.addEventListener('click', () => {
    void storageSet(STORE.RATED, true);
    document.getElementById('rateModal')?.classList.remove('on');
  });
}

function bindPlatformButtons() {
  document.querySelectorAll('[data-channel][data-open]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const url = btn.getAttribute('data-open');
      if (!url) return;
      if (typeof chrome !== 'undefined' && chrome.tabs?.create) {
        chrome.tabs.create({ url }).catch(() => window.open(url, '_blank', 'noopener'));
        return;
      }
      window.open(url, '_blank', 'noopener');
    });
  });
}

const CV_BATCH_MAX = 25;
const cvBatch = [];
let cvBatchSeq = 0;
let cvBatchBusy = false;

function analyzeCvCountLabel(count) {
  const n = Math.max(0, Number(count) || 0);
  if (n === 1) return 'Analyze 1 CV';
  if (n > 1) return `Analyze ${n} CVs`;
  return 'Analyze CVs';
}

function asStringList(items) {
  if (!Array.isArray(items)) return [];
  return items.map((item) => {
    if (typeof item === 'string') return item.trim();
    return String(item?.area || item?.detail || item?.skill || item?.name || '').trim();
  }).filter(Boolean).slice(0, 6);
}

function candidateFitScore(data) {
  const n = Number(data?.overallScore ?? data?.matchScore ?? data?.compatibilityScore ?? 0);
  return Number.isFinite(n) ? Math.max(0, Math.min(100, Math.round(n))) : 0;
}

function jobBriefData(pageData) {
  const pageText = String(pageData?.pageText || pageData?.jobDescription || lastJob.description || '').trim();
  return {
    pageText,
    pageTitle: pageData?.pageTitle || lastJob.title || 'Active job brief',
    pageUrl: pageData?.pageUrl || lastJob.url || '',
    jobTitle: pageData?.jobTitle || lastJob.title || pageData?.pageTitle || 'Active job brief',
    jobDescription: pageData?.jobDescription || lastJob.description || pageText,
    requiredSkills: pageData?.requiredSkills || lastJob.skills || [],
    budget: pageData?.budget || lastJob.budget || '',
    clientHistory: pageData?.clientHistory || lastJob.clientHistory || '',
    structuredJob: pageData?.structuredJob || null,
  };
}

function loadedCvCount() {
  return cvBatch.filter((item) => String(item.text || '').trim().length >= 20).length;
}

function syncAnalyzeButton() {
  const btn = document.getElementById('cvBatchAnalyze');
  const count = loadedCvCount();
  if (!btn) return;
  btn.textContent = cvBatchBusy
    ? `Analyzing ${cvBatch.filter((item) => item.phase === 'ready' || item.phase === 'error').length}/${count}…`
    : analyzeCvCountLabel(count);
  btn.disabled = cvBatchBusy || count < 1;
}

function renderCvBatchList() {
  const list = document.getElementById('cvBatchList');
  if (!list) return;
  if (!cvBatch.length) {
    list.innerHTML = '';
    syncAnalyzeButton();
    return;
  }
  list.innerHTML = cvBatch.map((item) => {
    const detail = item.error
      ? item.error
      : item.phase === 'analyzing'
        ? 'Scoring against the job brief…'
        : item.phase === 'ready'
          ? `Fit ${candidateFitScore(item.result)}/100`
          : item.phase === 'loaded'
            ? 'Ready to analyze'
            : 'Reading file…';
    return `<article class="cv-batch-row" data-id="${escapeHtml(item.id)}">
      <div>
        <b>${escapeHtml(item.name || 'Untitled CV')}</b>
        <small>${escapeHtml(detail)}</small>
      </div>
      <span class="meta">${escapeHtml(item.phase === 'ready' ? `${candidateFitScore(item.result)}` : '—')}</span>
      <button class="danger" type="button" data-remove-cv="${escapeHtml(item.id)}">Remove</button>
    </article>`;
  }).join('');
  syncAnalyzeButton();
}

async function addCvFiles(fileList) {
  const files = Array.from(fileList || []).filter(Boolean).slice(0, CV_BATCH_MAX);
  if (!files.length) return;
  const status = document.getElementById('candidateBlockStatus');
  const remaining = Math.max(0, CV_BATCH_MAX - cvBatch.length);
  const queued = files.slice(0, remaining);
  if (!queued.length) {
    if (status) {
      status.textContent = `Queue is full (${CV_BATCH_MAX} CVs max).`;
      status.classList.add('err');
    }
    return;
  }
  if (status) {
    status.classList.remove('err');
    status.textContent = `Reading ${queued.length} file${queued.length === 1 ? '' : 's'}…`;
  }
  await Promise.all(queued.map(async (file) => {
    const name = String(file.name || 'Untitled CV');
    const signature = `${name}:${file.size || 0}`;
    if (cvBatch.some((item) => item.signature === signature)) return;
    const row = {
      id: `cv-${Date.now()}-${cvBatchSeq += 1}`,
      name,
      signature,
      text: '',
      result: null,
      error: '',
      phase: 'reading',
      shortlisted: false,
    };
    cvBatch.push(row);
    renderCvBatchList();
    try {
      const text = await withTimeout(
        extractDroppedFile(file),
        12000,
        'That file took too long to read. Try a TXT or HTML export.',
      );
      row.text = text;
      row.phase = 'loaded';
      row.error = '';
    } catch (err) {
      row.phase = 'error';
      row.error = fileAnalysisError(err);
    }
    renderCvBatchList();
  }));
  const count = loadedCvCount();
  if (status) {
    status.classList.toggle('err', count < 1);
    status.textContent = count
      ? `${count} CV${count === 1 ? '' : 's'} ready. ${analyzeCvCountLabel(count)} against the active job brief.`
      : 'No readable CVs yet. Drop a PDF, DOCX, TXT, or HTML resume.';
  }
  syncAnalyzeButton();
}

function clearCvBatch() {
  cvBatchSeq += 1;
  cvBatch.splice(0, cvBatch.length);
  cvBatchBusy = false;
  renderCvBatchList();
  const status = document.getElementById('candidateBlockStatus');
  if (status) {
    status.classList.remove('err');
    status.textContent = 'No CVs loaded yet.';
  }
  blockSpinner('candidate')?.classList.remove('on');
}

function rankPayload() {
  const ranked = [...cvBatch]
    .filter((item) => item.phase === 'ready' && item.result)
    .sort((a, b) => candidateFitScore(b.result) - candidateFitScore(a.result));
  return {
    jobTitle: lastJob.title || 'Active job brief',
    jobUrl: lastJob.url || '',
    candidates: ranked.map((item, index) => ({
      id: item.id,
      rank: index + 1,
      name: item.name || 'Candidate',
      score: candidateFitScore(item.result),
      summary: String(item.result?.summary || item.result?.whyThisCandidate || '').slice(0, 280),
      highlights: asStringList(item.result?.skillMatches || item.result?.pros || item.result?.strengths),
      gaps: asStringList(item.result?.candidateGaps || item.result?.cons || item.result?.gaps),
      shortlisted: Boolean(item.shortlisted),
    })),
  };
}

function renderRankDrawer(payload) {
  const drawer = document.getElementById('rankDrawer');
  const backdrop = document.getElementById('rankBackdrop');
  const list = document.getElementById('rankDrawerList');
  const meta = document.getElementById('rankDrawerMeta');
  if (!drawer || !list) return;
  const rows = Array.isArray(payload?.candidates) ? payload.candidates : [];
  if (meta) meta.textContent = rows.length
    ? `${rows.length} candidate${rows.length === 1 ? '' : 's'} ranked vs ${payload?.jobTitle || 'the active job brief'}.`
    : 'Analyze CVs to see rankings.';
  list.innerHTML = rows.length ? rows.map((row) => `
    <article class="rank-row" data-id="${escapeHtml(row.id)}">
      <div class="score-row">
        <div class="score" style="--p:${Number(row.score) || 0}"><span>${escapeHtml(String(row.score ?? '—'))}</span></div>
        <div>
          <p class="title">#${escapeHtml(String(row.rank))} · ${escapeHtml(row.name || 'Candidate')}</p>
          <p class="meta">Fit ${escapeHtml(String(row.score))}/100</p>
        </div>
      </div>
      <p>${escapeHtml(row.summary || 'No summary yet.')}</p>
      <div class="k">Highlights</div>
      <p>${escapeHtml((row.highlights || []).join(' · ') || 'None listed.')}</p>
      <div class="k">Skill gaps</div>
      <p>${escapeHtml((row.gaps || []).join(' · ') || 'None listed.')}</p>
      <div class="row">
        <button class="primary" type="button" data-rank-action="proposal" data-id="${escapeHtml(row.id)}">Generate Tailored Proposal</button>
        <button class="cv" type="button" data-rank-action="shortlist" data-id="${escapeHtml(row.id)}">${row.shortlisted ? 'Shortlisted' : 'Shortlist Candidate'}</button>
      </div>
    </article>
  `).join('') : '<div class="empty">No scored CVs yet.</div>';
  drawer.classList.add('open');
  drawer.setAttribute('aria-hidden', 'false');
  backdrop?.classList.add('open');
}

function closeRankDrawer() {
  const drawer = document.getElementById('rankDrawer');
  drawer?.classList.remove('open');
  drawer?.setAttribute('aria-hidden', 'true');
  document.getElementById('rankBackdrop')?.classList.remove('open');
}

async function pushRanksToPage() {
  const payload = rankPayload();
  if (!payload.candidates.length) return false;
  try {
    const res = await withTimeout(
      chrome.runtime.sendMessage({ type: 'OPEN_RANKS_FLYOUT', payload }),
      4000,
      'Rankings panel timed out.',
    );
    return Boolean(res?.success);
  } catch (err) {
    console.warn('[sovereign] page flyout', err?.message || err);
    return false;
  }
}

async function openRanksFlyout(forceDrawer) {
  const payload = rankPayload();
  if (!payload.candidates.length) {
    const status = document.getElementById('candidateBlockStatus');
    if (status) {
      status.classList.remove('err');
      status.textContent = 'Score at least one CV to open the rankings panel.';
    }
    if (forceDrawer) renderRankDrawer(payload);
    return;
  }
  if (forceDrawer) {
    renderRankDrawer(payload);
    return;
  }
  const onPage = await pushRanksToPage();
  if (onPage) {
    closeRankDrawer();
    return;
  }
  renderRankDrawer(payload);
}

async function handleRankAction(action, id) {
  const item = cvBatch.find((row) => row.id === id);
  if (!item) return;
  if (action === 'shortlist') {
    item.shortlisted = true;
    await saveCandidateRecord({
      id: item.id,
      title: item.name || 'Candidate',
      role: lastJob.title || '',
      url: lastJob.url || '',
      summary: [
        item.name || 'Candidate',
        lastJob.title || '',
        `Fit ${candidateFitScore(item.result)}/100`,
        item.result?.summary || '',
      ].filter(Boolean).join('\n'),
      score: candidateFitScore(item.result),
      at: Date.now(),
    });
    const status = document.getElementById('candidateBlockStatus');
    if (status) {
      status.classList.remove('err');
      status.textContent = `${item.name || 'Candidate'} shortlisted locally.`;
    }
    renderCvBatchList();
    void openRanksFlyout(document.getElementById('rankDrawer')?.classList.contains('open'));
    return;
  }
  if (action === 'proposal') {
    b2bBlocks.candidate.fileName = item.name || 'Candidate CV';
    b2bBlocks.candidate.text = item.text || '';
    b2bBlocks.candidate.result = item.result || null;
    b2bBlocks.candidate.error = '';
    b2bBlocks.candidate.phase = item.text ? 'loaded' : '';
    b2bBlocks.proposal.fileName = item.name || 'Candidate CV';
    b2bBlocks.proposal.text = item.text || '';
    b2bBlocks.proposal.result = null;
    b2bBlocks.proposal.error = '';
    b2bBlocks.proposal.phase = item.text ? 'loaded' : '';
    closeRankDrawer();
    try {
      await chrome.runtime.sendMessage({ type: 'CLOSE_RANKS_FLYOUT' }).catch(() => null);
    } catch {
      // Host page flyout is optional.
    }
    switchTab('b2b-proposal');
    await runB2bBlock('proposal');
  }
}

async function analyzeCvBatch() {
  if (cvBatchBusy) return;
  const pending = cvBatch.filter((item) => String(item.text || '').trim().length >= 20);
  if (!pending.length) {
    setBlockStatus('candidate', 'Drop at least one readable CV first.', true);
    syncAnalyzeButton();
    return;
  }
  const runId = (cvBatchSeq += 1);
  cvBatchBusy = true;
  syncAnalyzeButton();
  blockSpinner('candidate')?.classList.add('on');
  setBlockStatus('candidate', `Analyzing ${pending.length} CV${pending.length === 1 ? '' : 's'} vs the active job brief…`, false);
  let pageData = null;
  try {
    pageData = await withTimeout(getActiveTabDOM(), 8000, 'The open page took too long to read.');
  } catch (err) {
    console.warn('[sovereign] job brief scrape skipped', err?.message || err);
    pageData = null;
  }
  const brief = jobBriefData(pageData);
  const hasBrief = String(brief.jobDescription || brief.pageText || '').trim().length >= 40;
  if (!hasBrief) {
    setBlockStatus('candidate', 'No job brief on the open page. Scan a job, then analyze. Scoring CVs anyway…', false);
  }
  for (const item of pending) {
    if (runId !== cvBatchSeq) break;
    item.phase = 'analyzing';
    item.error = '';
    renderCvBatchList();
    try {
      const data = await withTimeout(postParseDom(hasBrief ? brief : {
        pageText: item.text,
        pageTitle: item.name || 'Uploaded document',
        pageUrl: '',
        jobTitle: item.name || 'Uploaded document',
        jobDescription: item.text,
        requiredSkills: [],
        budget: '',
        clientHistory: '',
      }, {
        analysisMode: 'candidate',
        uploadedText: item.text,
      }), 35000, 'Analysis took too long. Try the file again.');
      if (runId !== cvBatchSeq) break;
      item.result = data;
      item.phase = 'ready';
      item.error = '';
      b2bBlocks.candidate.fileName = item.name;
      b2bBlocks.candidate.text = item.text;
      b2bBlocks.candidate.result = data;
      b2bBlocks.candidate.phase = 'ready';
      renderB2bBlock('candidate');
      if (document.getElementById('rankDrawer')?.classList.contains('open')) {
        renderRankDrawer(rankPayload());
      } else {
        void pushRanksToPage();
      }
      void noteAiSuccess();
    } catch (err) {
      if (runId !== cvBatchSeq) break;
      item.phase = 'error';
      item.result = null;
      item.error = fileAnalysisError(err);
    }
    renderCvBatchList();
  }
  if (runId === cvBatchSeq) {
    cvBatchBusy = false;
    blockSpinner('candidate')?.classList.remove('on');
    const ready = cvBatch.filter((item) => item.phase === 'ready').length;
    const failed = cvBatch.filter((item) => item.phase === 'error').length;
    setBlockStatus(
      'candidate',
      ready
        ? `${ready} CV${ready === 1 ? '' : 's'} ranked${failed ? ` · ${failed} failed` : ''}. Rankings opened beside the page.`
        : 'Could not score these CVs. Check the files and try again.',
      ready < 1,
    );
    syncAnalyzeButton();
    if (ready) void openRanksFlyout(false);
  }
}

function guideCopy() {
  const b2b = effectiveMode() === 'b2b';
  const banner = document.getElementById('guideBannerCopy');
  if (banner) {
    banner.textContent = b2b
      ? 'Candidate, Proposal, Leads, Dispatch, Team, Settings. Tap to see what each action does.'
      : 'Instant, Proposal, CV, Match, Settings. Tap to see what each action does.';
  }
  const title = document.getElementById('guideTitle');
  if (title) title.textContent = b2b ? 'Agency workspace guide' : 'How this extension works';
  const body = document.getElementById('guideBody');
  if (!body) return;
  const tabs = b2b ? [
    ['Candidate', 'Drop one or many CVs. Analyze scores every resume against the job currently open in the browser.'],
    ['Proposal', 'Generate a tailored agency cover letter from the scanned job and a selected candidate CV.'],
    ['Leads', 'Extract client details and a cold-outreach draft from the page you are viewing.'],
    ['Dispatch', 'Route scored work to your agency workspace without leaving the job board.'],
    ['Team', 'Keep local notes and team context on this device.'],
    ['Settings', 'Profile, language, theme, and API connection for this Chrome profile.'],
  ] : [
    ['Instant', 'Paste or drop a job post for an immediate fit score, poach alert, and resume armor preview.'],
    ['Proposal', 'Generate a tailored cover letter from the scanned job. Copy or Auto-Fill. Sovereign never submits.'],
    ['CV', 'Build a tailored CV for the active job, then copy or download the PDF.'],
    ['Match', 'See strengths and skill gaps versus the job currently on screen.'],
    ['Settings', 'Skills, rates, language, theme, and connection status for this Chrome profile.'],
  ];
  const actions = b2b ? [
    ['Scan Active Screen', 'Reads the job (or CV) in the visible tab and stores it as the active brief.'],
    ['Upload / Dropzone', 'Adds PDF, DOCX, TXT, or HTML resumes to the Candidate queue.'],
    ['Analyze {n} CVs', 'Scores every loaded CV in the background, then opens the rankings flyout to the left of this panel.'],
    ['Generate Tailored Proposal', 'Opens Proposal for that candidate and drafts a cover letter against the job brief.'],
    ['Shortlist Candidate', 'Saves the ranked candidate locally in this extension.'],
  ] : [
    ['Scan Active Screen', 'Reads the job currently visible in the tab. Use this before generating a proposal or CV.'],
    ['Upload', 'Drop a job description or resume into Instant to score without scraping the page.'],
    ['Generate Proposal', 'Writes a cover letter from the scanned job and your settings.'],
    ['Auto-Fill / Deploy', 'Inserts text into the page editor. You review and send. Sovereign never auto-submits.'],
    ['Generate Tailored CV', 'Builds a CV matched to the open job.'],
  ];
  body.innerHTML = [
    ...tabs.map(([label, text]) => `<article class="guide-item"><strong>${label}</strong><p>${text}</p></article>`),
    '<p class="k">Action buttons</p>',
    ...actions.map(([label, text]) => `<article class="guide-item"><strong>${label}</strong><p>${text}</p></article>`),
  ].join('');
}

function syncGuideBanner() {
  guideCopy();
}

function setGuideOpen(open) {
  const modal = document.getElementById('guideModal');
  if (!modal) return;
  if (open) guideCopy();
  modal.classList.toggle('on', Boolean(open));
}

function bindQuickGuide() {
  document.getElementById('guideOpen')?.addEventListener('click', () => setGuideOpen(true));
  document.getElementById('guideBanner')?.addEventListener('click', () => setGuideOpen(true));
  document.getElementById('guideClose')?.addEventListener('click', () => setGuideOpen(false));
  document.getElementById('guideModal')?.addEventListener('click', (event) => {
    if (event.target === event.currentTarget) setGuideOpen(false);
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      setGuideOpen(false);
      closeRankDrawer();
    }
  });
  syncGuideBanner();
}

function bindCvBatchAnalyzer() {
  const drop = document.getElementById('cvBatchDrop');
  const input = document.getElementById('cvBatchFile');
  drop?.addEventListener('click', () => input?.click());
  drop?.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      input?.click();
    }
  });
  drop?.addEventListener('dragover', (event) => {
    event.preventDefault();
    drop.classList.add('over');
  });
  drop?.addEventListener('dragleave', () => drop.classList.remove('over'));
  drop?.addEventListener('drop', (event) => {
    event.preventDefault();
    drop.classList.remove('over');
    void addCvFiles(event.dataTransfer?.files);
  });
  input?.addEventListener('change', (event) => {
    const files = event.target.files;
    event.target.value = '';
    void addCvFiles(files);
  });
  document.getElementById('cvBatchClear')?.addEventListener('click', () => clearCvBatch());
  document.getElementById('cvBatchAnalyze')?.addEventListener('click', () => { void analyzeCvBatch(); });
  document.getElementById('cvBatchOpenRanks')?.addEventListener('click', () => { void openRanksFlyout(true); });
  document.getElementById('cvBatchList')?.addEventListener('click', (event) => {
    const id = event.target.closest('[data-remove-cv]')?.getAttribute('data-remove-cv');
    if (!id) return;
    const index = cvBatch.findIndex((item) => item.id === id);
    if (index >= 0) cvBatch.splice(index, 1);
    renderCvBatchList();
    const count = loadedCvCount();
    setBlockStatus('candidate', count ? `${count} CV${count === 1 ? '' : 's'} in queue.` : 'No CVs loaded yet.', false);
  });
}

function bindRankDrawer() {
  document.getElementById('rankDrawerClose')?.addEventListener('click', () => closeRankDrawer());
  document.getElementById('rankBackdrop')?.addEventListener('click', () => closeRankDrawer());
  document.getElementById('rankDrawerList')?.addEventListener('click', (event) => {
    const btn = event.target.closest('[data-rank-action]');
    if (!btn) return;
    void handleRankAction(btn.getAttribute('data-rank-action'), btn.getAttribute('data-id'));
  });
  if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
      if (request?.type !== 'FLYOUT_ACTION') return false;
      void handleRankAction(request.action, request.id)
        .then(() => sendResponse({ success: true }))
        .catch((err) => sendResponse({ success: false, error: err?.message || String(err) }));
      return true;
    });
  }
}

async function boot() {
  bindPlatformButtons();
  bindInstant();
  bindQuickGuide();
  bindCvBatchAnalyzer();
  bindRankDrawer();
  try {
    const stored = await storageGet(STORE.SETTINGS, DEFAULT_SETTINGS);
    settings = { ...DEFAULT_SETTINGS, ...(stored || {}) };
    if (settings.languageChoice !== 'auto' && (!settings.outputLanguage || settings.outputLanguage === 'auto')) {
      settings.outputLanguage = 'en';
      settings.languageChoice = 'explicit';
    }
    fillSettingsForm();
    const guest = await guestState();
    settings._guestUsed = guest.used;
    applyCreditBadge();
    await loadDefaultCv();
    renderProposalList(await storageGet(STORE.PROPOSALS, []));
    renderCvList(await storageGet(STORE.CVS, []));
    void renderSettingsHistory();
    renderTeamLeads(await storageGet(STORE.LEADS, []));
    await resolveWorkspaceAccess();
    setTargetBadge('idle');
    void autoFillFromActiveTab();
  } catch (err) {
    showError(err?.message || 'Could not load local settings.');
  }
  void pingApi();
}

if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes[STORE.SETTINGS]?.newValue) {
      const incoming = { ...DEFAULT_SETTINGS, ...changes[STORE.SETTINGS].newValue };
      const incomingRev = Number(incoming._settingsRev || 0);
      if (incomingRev < settingsRevision) {
        incoming.workspaceMode = settings.workspaceMode;
        incoming.workspace = settings.workspace;
        incoming._settingsRev = settingsRevision;
      } else if (incomingRev > settingsRevision) {
        settingsRevision = incomingRev;
      }
      settings = incoming;
      try { fillSettingsForm(); } catch (err) { console.error('[sovereign] settings sync', err); }
    }
    if (changes[STORE.SESSION]?.newValue) {
      void resolveWorkspaceAccess();
    }
  });
}

boot();
